// ============================================
// Second Brain - Web Panel Application
// ============================================

const API = '';
let currentCategory = 'all';
let currentPage = 1;
let searchTimeout = null;

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  loadCategories();
  loadContent();
  setupSearchListener();
  setupKeyboardShortcuts();
});

// ============================================
// Data Loading
// ============================================

async function loadStats() {
  try {
    const stats = await fetchJson('/api/stats');
    document.getElementById('totalCount').textContent = `${stats.total} items`;
    document.getElementById('pendingCount').textContent = `${stats.pending} pendientes`;
    document.getElementById('count-all').textContent = stats.total;

    // Platform stats
    const platformEl = document.getElementById('platformStats');
    const platformEmojis = {
      youtube: '🎬', twitter: '🐦', instagram: '📸',
      linkedin: '💼', web: '🌐', unknown: '❓'
    };
    platformEl.innerHTML = stats.byPlatform
      .map(p => `<div class="platform-item">
        <span>${platformEmojis[p.source_platform] || '📌'} ${p.source_platform}</span>
        <span>${p.count}</span>
      </div>`).join('');
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

async function loadCategories() {
  try {
    const stats = await fetchJson('/api/stats');
    const nav = document.getElementById('categoryNav');

    // Keep the "Todos" link
    const allLink = nav.querySelector('[data-slug="all"]');

    // Add category links
    stats.byCategory.forEach(cat => {
      const link = document.createElement('a');
      link.href = '#';
      link.className = 'cat-link';
      link.dataset.slug = cat.slug;
      link.innerHTML = `
        <span class="cat-icon">${cat.icon}</span>
        <span class="cat-name">${cat.name}</span>
        <span class="cat-count">${cat.count}</span>
      `;
      link.addEventListener('click', (e) => {
        e.preventDefault();
        setActiveCategory(cat.slug);
      });
      nav.appendChild(link);
    });

    // Set up "Todos" click
    allLink.addEventListener('click', (e) => {
      e.preventDefault();
      setActiveCategory('all');
    });
  } catch (err) {
    console.error('Failed to load categories:', err);
  }
}

async function loadContent(category, page = 1) {
  const grid = document.getElementById('contentGrid');
  const empty = document.getElementById('emptyState');
  const loading = document.getElementById('loading');

  grid.style.display = 'none';
  empty.style.display = 'none';
  loading.style.display = 'block';

  try {
    const params = new URLSearchParams({ page, limit: 20 });
    if (category && category !== 'all') params.set('category', category);

    const data = await fetchJson(`/api/content?${params}`);

    loading.style.display = 'none';

    if (data.items.length === 0) {
      empty.style.display = 'block';
      document.getElementById('pagination').innerHTML = '';
      return;
    }

    grid.style.display = 'grid';
    grid.innerHTML = data.items.map(item => createCard(item)).join('');
    renderPagination(data.page, data.totalPages);
  } catch (err) {
    loading.style.display = 'none';
    console.error('Failed to load content:', err);
  }
}

async function searchContent(query) {
  const grid = document.getElementById('contentGrid');
  const empty = document.getElementById('emptyState');
  const loading = document.getElementById('loading');

  if (!query || query.length < 2) {
    loadContent(currentCategory, 1);
    return;
  }

  grid.style.display = 'none';
  empty.style.display = 'none';
  loading.style.display = 'block';

  try {
    const data = await fetchJson(`/api/search?q=${encodeURIComponent(query)}`);
    loading.style.display = 'none';

    if (data.results.length === 0) {
      empty.style.display = 'block';
      empty.querySelector('h3').textContent = `No se encontró nada para "${query}"`;
      document.getElementById('pagination').innerHTML = '';
      return;
    }

    grid.style.display = 'grid';
    grid.innerHTML = data.results.map(r => createCard(r.item)).join('');
    document.getElementById('pagination').innerHTML = '';
  } catch (err) {
    loading.style.display = 'none';
    console.error('Search failed:', err);
  }
}

// ============================================
// UI Components
// ============================================

function createCard(item) {
  const platformEmoji = {
    youtube: '🎬', twitter: '🐦', instagram: '📸',
    linkedin: '💼', web: '🌐', unknown: '📌'
  };

  const tags = safeParse(item.tags, []).slice(0, 4);
  const date = formatDate(item.added_date);
  const catColor = item.category_color || '#6B7280';

  return `
    <div class="content-card" onclick="openDetail(${item.id})">
      <div class="card-header">
        <div class="card-platform">${platformEmoji[item.source_platform] || '📌'}</div>
        <div class="card-title">${escapeHtml(item.title || 'Sin título')}</div>
      </div>
      <div class="card-summary">${escapeHtml(item.summary || '')}</div>
      <div class="card-tags">
        ${tags.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join('')}
      </div>
      <div class="card-footer">
        <span class="card-category" style="color:${catColor}; border-color:${catColor}30">
          ${item.category_icon || '📌'} ${escapeHtml(item.category_name || 'Sin categoría')}
        </span>
        <span class="card-date">${date}</span>
      </div>
    </div>
  `;
}

function renderPagination(current, total) {
  const el = document.getElementById('pagination');
  if (total <= 1) { el.innerHTML = ''; return; }

  let html = '';
  html += `<button ${current <= 1 ? 'disabled' : ''} onclick="goToPage(${current - 1})">&larr;</button>`;
  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= current - 2 && i <= current + 2)) {
      html += `<button class="${i === current ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
    } else if (i === current - 3 || i === current + 3) {
      html += `<button disabled>...</button>`;
    }
  }
  html += `<button ${current >= total ? 'disabled' : ''} onclick="goToPage(${current + 1})">&rarr;</button>`;
  el.innerHTML = html;
}

// ============================================
// Detail Modal
// ============================================

async function openDetail(id) {
  try {
    const item = await fetchJson(`/api/content/${id}`);
    const keyPoints = safeParse(item.key_points, []);
    const extractedUrls = safeParse(item.extracted_urls, []);
    const tags = safeParse(item.tags, []);

    const modalBody = document.getElementById('modalBody');
    modalBody.innerHTML = `
      <h2 class="detail-title">${escapeHtml(item.title || 'Sin título')}</h2>
      <div class="detail-meta">
        <span>📅 ${formatDate(item.added_date)}</span>
        <span>📂 ${escapeHtml(item.category_name || 'Sin categoría')}</span>
        <span>🔗 ${item.source_platform}</span>
      </div>

      <div class="detail-section">
        <h3>Resumen</h3>
        <p class="detail-summary">${escapeHtml(item.summary || 'Sin resumen disponible.')}</p>
      </div>

      ${keyPoints.length > 0 ? `
      <div class="detail-section">
        <h3>Puntos clave</h3>
        <ul class="detail-key-points">
          ${keyPoints.map(p => `<li>${escapeHtml(p)}</li>`).join('')}
        </ul>
      </div>
      ` : ''}

      ${tags.length > 0 ? `
      <div class="detail-section">
        <h3>Tags</h3>
        <div class="card-tags">
          ${tags.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join('')}
        </div>
      </div>
      ` : ''}

      ${extractedUrls.length > 0 ? `
      <div class="detail-section">
        <h3>Enlaces mencionados</h3>
        <div class="detail-urls">
          ${extractedUrls.map(u => `<a href="${escapeHtml(u.url)}" target="_blank" rel="noopener">${escapeHtml(u.context || u.url)}</a>`).join('')}
        </div>
      </div>
      ` : ''}

      <div class="detail-section">
        <h3>Categoría</h3>
        <div class="category-selector">
          <select id="categorySelect" onchange="changeCategory(${item.id}, this.value)">
            ${await getCategoryOptions(item.category_id)}
          </select>
        </div>
      </div>

      <div class="detail-section">
        <h3>Editar Tags</h3>
        <div class="tag-editor">
          <div class="tag-editor-current" id="tagEditorCurrent">
            ${tags.map(t => `<span class="tag tag-removable" onclick="removeTag(${item.id}, '${escapeHtml(t)}')">${escapeHtml(t)} ×</span>`).join('')}
          </div>
          <div class="tag-editor-input">
            <input type="text" id="newTagInput" placeholder="Nuevo tag..." onkeydown="if(event.key==='Enter')addTag(${item.id})">
            <button onclick="addTag(${item.id})" class="tag-add-btn">+ Añadir</button>
          </div>
        </div>
      </div>

      <div class="detail-actions">
        <a href="${escapeHtml(item.url)}" target="_blank" rel="noopener" class="detail-link">Ver contenido original →</a>
        <button onclick="deleteContent(${item.id})" class="delete-btn">🗑️ Eliminar</button>
      </div>
    `;

    // Store current item data for tag operations
    window._currentDetailItem = item;
    window._currentDetailTags = tags;

    document.getElementById('detailModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
  } catch (err) {
    console.error('Failed to load detail:', err);
  }
}

async function getCategoryOptions(currentCatId) {
  try {
    const categories = await fetchJson('/api/categories');
    return categories.map(c =>
      `<option value="${c.id}" ${c.id === currentCatId ? 'selected' : ''}>${c.icon} ${c.name}</option>`
    ).join('');
  } catch { return ''; }
}

async function changeCategory(itemId, categoryId) {
  try {
    await fetch('/api/content/' + itemId, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category_id: parseInt(categoryId) })
    });
    loadStats();
    loadContent(currentCategory, currentPage);
  } catch (err) { console.error('Category change failed:', err); }
}

async function addNewCategory() {
  const name = prompt('Nombre de la nueva categoría:');
  if (!name || !name.trim()) return;
  const icon = prompt('Emoji/icono (opcional):', '📌') || '📌';
  try {
    const res = await fetch('/api/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name.trim(), icon })
    });
    if (res.ok) {
      loadStats();
      loadCategories();
      alert('Categoría creada: ' + name);
    } else {
      const err = await res.json();
      alert('Error: ' + err.error);
    }
  } catch (err) { console.error('Failed to create category:', err); }
}

async function deleteContent(itemId) {
  if (!confirm('¿Seguro que quieres eliminar este contenido?')) return;
  try {
    const res = await fetch('/api/content/' + itemId, { method: 'DELETE' });
    if (res.ok) {
      closeModal();
      loadStats();
      loadContent(currentCategory, currentPage);
    } else {
      alert('Error al eliminar');
    }
  } catch (err) { console.error('Delete failed:', err); }
}

async function addTag(itemId) {
  const input = document.getElementById('newTagInput');
  const tag = input.value.trim();
  if (!tag) return;

  const tags = window._currentDetailTags || [];
  if (tags.includes(tag)) { input.value = ''; return; }
  tags.push(tag);

  try {
    await fetch('/api/content/' + itemId, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tags })
    });
    window._currentDetailTags = tags;
    input.value = '';
    openDetail(itemId); // Refresh modal
    loadContent(currentCategory, currentPage); // Refresh grid
  } catch (err) { console.error('Failed to add tag:', err); }
}

async function removeTag(itemId, tagToRemove) {
  const tags = (window._currentDetailTags || []).filter(t => t !== tagToRemove);

  try {
    await fetch('/api/content/' + itemId, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tags })
    });
    window._currentDetailTags = tags;
    openDetail(itemId);
    loadContent(currentCategory, currentPage);
  } catch (err) { console.error('Failed to remove tag:', err); }
}

function closeModal() {
  document.getElementById('detailModal').style.display = 'none';
  document.body.style.overflow = '';
}

// ============================================
// Event Handlers
// ============================================

function setActiveCategory(slug) {
  currentCategory = slug;
  currentPage = 1;

  document.querySelectorAll('.cat-link').forEach(el => {
    el.classList.toggle('active', el.dataset.slug === slug);
  });

  document.getElementById('searchInput').value = '';
  loadContent(slug, 1);
}

function goToPage(page) {
  currentPage = page;
  loadContent(currentCategory, page);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setupSearchListener() {
  const input = document.getElementById('searchInput');
  input.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      searchContent(e.target.value.trim());
    }, 400);
  });
}

async function triggerProcess() {
  const btn = document.getElementById('processBtn');
  const originalText = btn.innerHTML;

  btn.disabled = true;
  btn.innerHTML = '⏳ Procesando...';
  btn.classList.add('processing');

  try {
    const res = await fetch('/api/process', { method: 'POST' });
    const data = await res.json();

    if (res.status === 409) {
      btn.innerHTML = '⏳ Ya en curso...';
    } else if (data.total === 0) {
      btn.innerHTML = '✅ Nada pendiente';
    } else {
      btn.innerHTML = `⚡ Procesando ${data.pending}...`;
      // Poll for completion
      pollProcessStatus(btn, originalText);
      return;
    }
  } catch (err) {
    btn.innerHTML = '❌ Error';
    console.error('Process failed:', err);
  }

  setTimeout(() => {
    btn.disabled = false;
    btn.innerHTML = originalText;
    btn.classList.remove('processing');
    loadStats();
    loadContent(currentCategory, currentPage);
  }, 3000);
}

function pollProcessStatus(btn, originalText) {
  const poll = setInterval(async () => {
    try {
      const res = await fetch('/api/process/status');
      const data = await res.json();

      if (!data.isProcessing) {
        clearInterval(poll);
        btn.innerHTML = '✅ Completado';
        btn.classList.remove('processing');
        loadStats();
        loadContent(currentCategory, currentPage);

        setTimeout(() => {
          btn.disabled = false;
          btn.innerHTML = originalText;
        }, 3000);
      } else {
        btn.innerHTML = `⏳ Quedan ${data.pending}...`;
      }
    } catch {
      clearInterval(poll);
      btn.disabled = false;
      btn.innerHTML = originalText;
      btn.classList.remove('processing');
    }
  }, 5000);
}

function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Cmd/Ctrl + K -> Focus search
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      document.getElementById('searchInput').focus();
    }
    // Escape -> Close modal
    if (e.key === 'Escape') {
      closeModal();
    }
  });
}

// ============================================
// Utilities
// ============================================

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function safeParse(json, fallback) {
  if (!json) return fallback;
  if (Array.isArray(json)) return json;
  try { return JSON.parse(json); } catch { return fallback; }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    return new Date(dateStr).toLocaleDateString('es-ES', {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  } catch { return dateStr; }
}
