import { Router } from 'express';
import * as db from '../database/db';
import { processBatch } from '../processors/batch-processor';

const router = Router();

// GET /api/stats
router.get('/stats', (req, res) => {
  try {
    const stats = db.getStats();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/categories
router.get('/categories', (req, res) => {
  try {
    const categories = db.getAllCategories();
    res.json(categories);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/content?category=tech&page=1&limit=20
router.get('/content', (req, res) => {
  try {
    const category = req.query.category as string | undefined;
    const page = parseInt(req.query.page as string) || 1;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);

    const result = db.getContentByCategory(category, page, limit);
    res.json({
      ...result,
      page,
      limit,
      totalPages: Math.ceil(result.total / limit),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/content/:id
router.get('/content/:id', (req, res) => {
  try {
    const item = db.getContentById(parseInt(req.params.id));
    if (!item) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/search?q=semillas&category=jardineria&limit=10
router.get('/search', (req, res) => {
  try {
    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ error: 'Query parameter "q" is required' });
    }
    const limit = Math.min(parseInt(req.query.limit as string) || 10, 50);
    const category = req.query.category as string | undefined;

    const results = db.searchContent(query, limit, category);
    res.json({ query, results, total: results.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/process — trigger batch processing on demand
let isProcessing = false;

router.post('/process', async (req, res) => {
  if (isProcessing) {
    return res.status(409).json({ error: 'Ya hay un procesamiento en curso' });
  }

  try {
    isProcessing = true;
    const stats = db.getStats();

    if (stats.pending === 0) {
      isProcessing = false;
      return res.json({ message: 'No hay items pendientes', processed: 0, failed: 0, total: 0 });
    }

    // Start processing and respond immediately with status
    res.json({ message: `Procesando ${stats.pending} items...`, pending: stats.pending, status: 'started' });

    // Process in background
    processBatch().finally(() => {
      isProcessing = false;
    });
  } catch (err: any) {
    isProcessing = false;
    res.status(500).json({ error: err.message });
  }
});

// GET /api/process/status — check if processing is running
router.get('/process/status', (req, res) => {
  const stats = db.getStats();
  res.json({ isProcessing, pending: stats.pending });
});

// PUT /api/content/:id — update tags, category, title, summary
router.put('/content/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const item = db.getContentById(id);
    if (!item) {
      return res.status(404).json({ error: 'Not found' });
    }

    const { tags, category_id, title, summary } = req.body;
    db.updateContentFull(id, { title, summary, tags, category_id });

    const updated = db.getContentById(id);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
