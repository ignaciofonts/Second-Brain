import TelegramBot from 'node-telegram-bot-api';
import { CONFIG } from '../config/constants';
import { logger } from '../config/logger';
import * as db from '../database/db';
import { searchContent } from '../database/db';
import { augmentedSearch, processContent } from './claude.service';
import { processBatch } from '../processors/batch-processor';
import { processQueueItem } from '../processors/content.processor';
import { isValidUrl, cleanUrl } from '../utils/url-detector';

let bot: TelegramBot;

// State for users waiting to provide descriptions or edit tags
const pendingDescriptions: Map<number, number> = new Map(); // chatId -> contentId
const pendingTagEdits: Map<number, number> = new Map(); // chatId -> contentId

export function startTelegramBot(): TelegramBot {
  bot = new TelegramBot(CONFIG.telegramToken, { polling: true });

  logger.info('Telegram bot starting...');

  // ============================================
  // /start - Welcome message
  // ============================================
  bot.onText(/\/start/, (msg) => {
    const welcome = `🧠 *Second Brain* - Tu memoria digital personal

Puedo guardar y organizar contenido de redes sociales para que lo consultes cuando quieras.

*Cómo usarme:*

📥 *Guardar contenido:* Envíame cualquier enlace (YouTube, Instagram, X, LinkedIn, web...)

🔍 *Buscar:* /buscar semillas de tomate
❓ *Preguntar:* /ask ¿qué herramientas tengo guardadas?
📊 *Categorías:* /categorias
📈 *Estadísticas:* /stats
⚡ *Procesar ahora:* /procesar (procesa la cola inmediatamente)
📋 *Últimos guardados:* /recientes
📝 *Describir contenido:* /describir <id>
🏷️ *Editar tags:* /tags <id>
📌 *Pendientes de descripción:* /pendientes

¡Envíame un enlace para empezar!`;

    bot.sendMessage(msg.chat.id, welcome, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /describir <id> - Add description to unprocessable content
  // ============================================
  bot.onText(/\/describir (\d+)/, async (msg, match) => {
    if (!match) return;
    const contentId = parseInt(match[1]);
    const item = db.getContentById(contentId);

    if (!item) {
      bot.sendMessage(msg.chat.id, '❌ No encontré ese contenido.');
      return;
    }

    pendingDescriptions.set(msg.chat.id, contentId);
    bot.sendMessage(
      msg.chat.id,
      `📝 *Describir contenido #${contentId}*\n\n🔗 ${item.url}\n\nEscribe una breve descripción (2-3 frases) de qué trata este contenido. Usaré tu descripción para categorizarlo y asignarle tags.`,
      { parse_mode: 'Markdown' }
    );
  });

  // ============================================
  // /tags <id> - Edit tags of a content item
  // ============================================
  bot.onText(/\/tags (\d+)/, async (msg, match) => {
    if (!match) return;
    const contentId = parseInt(match[1]);
    const item = db.getContentById(contentId);

    if (!item) {
      bot.sendMessage(msg.chat.id, '❌ No encontré ese contenido.');
      return;
    }

    const currentTags = item.tags ? JSON.parse(item.tags as string) : [];
    pendingTagEdits.set(msg.chat.id, contentId);
    bot.sendMessage(
      msg.chat.id,
      `🏷️ *Editar tags de:* "${escapeMarkdown(item.title || 'Sin título')}"\n\n` +
      `Tags actuales: ${currentTags.length > 0 ? currentTags.join(', ') : '_ninguno_'}\n\n` +
      `Escribe los nuevos tags separados por comas.\nEjemplo: _herramientas, bricolaje, taladro_`,
      { parse_mode: 'Markdown' }
    );
  });

  // ============================================
  // /pendientes - Show content pending description
  // ============================================
  bot.onText(/\/pendientes/, async (msg) => {
    const database = db.getDb();
    const items = database.prepare(
      `SELECT id, url, title, source_platform FROM content_items WHERE status = 'pending_description' ORDER BY added_date DESC LIMIT 20`
    ).all() as any[];

    if (items.length === 0) {
      bot.sendMessage(msg.chat.id, '✅ No hay contenido pendiente de descripción.');
      return;
    }

    const list = items.map((item: any) =>
      `📌 *#${item.id}* ${platformEmoji(item.source_platform)} ${escapeMarkdown(item.title || 'Sin título')}\n   🔗 ${item.url}\n   → /describir ${item.id}`
    ).join('\n\n');

    bot.sendMessage(
      msg.chat.id,
      `📝 *Contenido pendiente de descripción:*\n\n${list}\n\n_Usa /describir <id> para añadir una descripción._`,
      { parse_mode: 'Markdown' }
    );
  });

  // ============================================
  // URL Detection - Add to queue
  // ============================================
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;

    const text = msg.text.trim();
    const chatId = msg.chat.id;

    // Check if user is providing a description for content
    if (pendingDescriptions.has(chatId)) {
      const contentId = pendingDescriptions.get(chatId)!;
      pendingDescriptions.delete(chatId);
      await handleDescription(chatId, contentId, text);
      return;
    }

    // Check if user is editing tags
    if (pendingTagEdits.has(chatId)) {
      const contentId = pendingTagEdits.get(chatId)!;
      pendingTagEdits.delete(chatId);
      await handleTagEdit(chatId, contentId, text);
      return;
    }

    // Check if it's a URL
    if (isValidUrl(text)) {
      await handleUrl(chatId, text);
      return;
    }

    // Check if message contains a URL among other text
    const urlMatch = text.match(/https?:\/\/[^\s]+/);
    if (urlMatch) {
      await handleUrl(chatId, urlMatch[0]);
      return;
    }

    // If it's just text (not a command, not a URL), treat it as a question
    await handleQuestion(chatId, text);
  });

  // ============================================
  // /buscar <query> - Search saved content
  // ============================================
  bot.onText(/\/buscar (.+)/, async (msg, match) => {
    if (!match) return;
    const query = match[1].trim();
    await handleSearch(msg.chat.id, query);
  });

  // ============================================
  // /ask <question> - Augmented search with Claude
  // ============================================
  bot.onText(/\/ask (.+)/, async (msg, match) => {
    if (!match) return;
    const question = match[1].trim();
    await handleQuestion(msg.chat.id, question);
  });

  // ============================================
  // /categorias - List categories with counts
  // ============================================
  bot.onText(/\/categorias/, async (msg) => {
    const stats = db.getStats();
    const catList = (stats.byCategory as any[])
      .filter((c: any) => c.count > 0)
      .map((c: any) => `${c.icon} *${c.name}*: ${c.count} items`)
      .join('\n');

    const message = catList
      ? `📂 *Tus categorías:*\n\n${catList}\n\n_Total: ${stats.total} contenidos guardados_`
      : '📂 Aún no tienes contenido guardado. ¡Envíame un enlace para empezar!';

    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /stats - Dashboard stats
  // ============================================
  bot.onText(/\/stats/, async (msg) => {
    const stats = db.getStats();
    const platformList = (stats.byPlatform as any[])
      .map((p: any) => `  ${platformEmoji(p.source_platform)} ${p.source_platform}: ${p.count}`)
      .join('\n');

    const message = `📈 *Estadísticas de tu Second Brain*

📚 Total guardados: *${stats.total}*
⏳ En cola: *${stats.pending}*

*Por plataforma:*
${platformList || '  Ninguna aún'}

*Últimos guardados:*
${(stats.recent as any[]).map((r: any) => `  ${r.icon || '📌'} ${r.title?.substring(0, 50)}`).join('\n') || '  Ninguno aún'}`;

    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /recientes - Last 10 saved items
  // ============================================
  bot.onText(/\/recientes/, async (msg) => {
    const { items } = db.getContentByCategory(undefined, 1, 10);
    if (items.length === 0) {
      bot.sendMessage(msg.chat.id, '📋 No hay contenido guardado aún.');
      return;
    }

    const list = items.map((item: any, i: number) =>
      `${i + 1}. ${item.category_icon || '📌'} *${escapeMarkdown(item.title || 'Sin título')}*\n   _${item.category_name || 'Sin categoría'}_ | ${formatDate(item.added_date)}\n   ${item.url}`
    ).join('\n\n');

    bot.sendMessage(msg.chat.id, `📋 *Últimos guardados:*\n\n${list}`, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /procesar - Process queue now
  // ============================================
  bot.onText(/\/procesar/, async (msg) => {
    const pending = db.getPendingQueueItems();
    if (pending.length === 0) {
      bot.sendMessage(msg.chat.id, '✅ No hay nada pendiente de procesar.');
      return;
    }

    bot.sendMessage(msg.chat.id, `⚙️ Procesando ${pending.length} items pendientes... Te aviso cuando termine.`);

    try {
      const result = await processBatch();
      bot.sendMessage(
        msg.chat.id,
        `✅ *Procesamiento completado*\n\n` +
        `📥 Procesados: ${result.processed}\n` +
        `❌ Fallidos: ${result.failed}\n` +
        `📊 Total: ${result.total}`,
        { parse_mode: 'Markdown' }
      );
    } catch (err) {
      bot.sendMessage(msg.chat.id, `❌ Error durante el procesamiento. Revisa los logs.`);
    }
  });

  // ============================================
  // /procesar_ya - Process a URL immediately (no queue)
  // ============================================
  bot.onText(/\/ya (.+)/, async (msg, match) => {
    if (!match) return;
    const url = match[1].trim();

    if (!isValidUrl(url)) {
      bot.sendMessage(msg.chat.id, '❌ Eso no parece una URL válida.');
      return;
    }

    bot.sendMessage(msg.chat.id, `⚡ Procesando inmediatamente: ${url}`);

    const queueItem = db.addToQueue(cleanUrl(url), msg.chat.id.toString());
    if (!queueItem) {
      bot.sendMessage(msg.chat.id, '⚠️ Esta URL ya está guardada o en cola.');
      return;
    }

    try {
      await processQueueItem(queueItem);
      bot.sendMessage(msg.chat.id, `✅ ¡Procesado y guardado en tu Second Brain!`);
    } catch (err: any) {
      bot.sendMessage(msg.chat.id, `❌ Error procesando: ${err.message?.substring(0, 100)}`);
    }
  });

  logger.info('Telegram bot started successfully');
  return bot;
}

// ============================================
// Handler functions
// ============================================

async function handleUrl(chatId: number, url: string): Promise<void> {
  const cleanedUrl = cleanUrl(url);
  const queueItem = db.addToQueue(cleanedUrl, chatId.toString());

  if (!queueItem) {
    bot.sendMessage(chatId, '⚠️ Esta URL ya está guardada o en cola de procesamiento.');
    return;
  }

  bot.sendMessage(
    chatId,
    `📥 *URL guardada en cola*\n\n🔗 ${cleanedUrl}\n\n_Se procesará automáticamente. Usa /procesar para procesarla ahora o /ya ${cleanedUrl} para procesamiento inmediato._`,
    { parse_mode: 'Markdown' }
  );
}

async function handleDescription(chatId: number, contentId: number, description: string): Promise<void> {
  bot.sendMessage(chatId, '🤔 Procesando tu descripción con Claude...');

  try {
    const item = db.getContentById(contentId);
    if (!item) {
      bot.sendMessage(chatId, '❌ No encontré ese contenido.');
      return;
    }

    // Use Claude to categorize based on user description
    const claudeResult = await processContent(
      description,
      item.url,
      item.source_platform || 'unknown',
      item.title || undefined
    );

    // Resolve category
    let category = db.getCategoryByName(claudeResult.category);
    if (!category) category = db.getCategoryBySlug('otro');

    // Update the content item
    db.updateContentFull(contentId, {
      title: claudeResult.title,
      summary: claudeResult.summary,
      tags: claudeResult.tags,
      category_id: category?.id,
    });

    // Update status to processed
    db.updateContentStatus(contentId, 'processed' as any);

    bot.sendMessage(
      chatId,
      `✅ *Contenido actualizado*\n\n` +
      `📌 *${escapeMarkdown(claudeResult.title)}*\n` +
      `📂 ${claudeResult.category}\n` +
      `🏷️ ${claudeResult.tags.join(', ')}\n\n` +
      `_${escapeMarkdown(claudeResult.summary)}_`,
      { parse_mode: 'Markdown' }
    );
  } catch (err: any) {
    logger.error(`Description processing failed: ${err.message}`);
    bot.sendMessage(chatId, `❌ Error al procesar la descripción: ${err.message?.substring(0, 100)}`);
  }
}

async function handleTagEdit(chatId: number, contentId: number, tagsText: string): Promise<void> {
  try {
    const newTags = tagsText.split(',').map(t => t.trim()).filter(t => t.length > 0);

    if (newTags.length === 0) {
      bot.sendMessage(chatId, '❌ No se detectaron tags válidos. Sepáralos con comas.');
      return;
    }

    db.updateContentTags(contentId, newTags);

    bot.sendMessage(
      chatId,
      `✅ *Tags actualizados*\n\n🏷️ ${newTags.join(', ')}`,
      { parse_mode: 'Markdown' }
    );
  } catch (err: any) {
    logger.error(`Tag edit failed: ${err.message}`);
    bot.sendMessage(chatId, `❌ Error al actualizar tags.`);
  }
}

async function handleSearch(chatId: number, query: string): Promise<void> {
  const results = searchContent(query, 5);

  if (results.length === 0) {
    bot.sendMessage(chatId, `🔍 No encontré nada para "${query}" en tu Second Brain.`);
    return;
  }

  const list = results.map((r, i) =>
    `${i + 1}. *${escapeMarkdown(r.item.title || 'Sin título')}*\n   📂 ${r.category_name}\n   ${r.snippet}...\n   🔗 ${r.item.url}`
  ).join('\n\n');

  bot.sendMessage(chatId, `🔍 *Resultados para "${escapeMarkdown(query)}":*\n\n${list}`, { parse_mode: 'Markdown' });
}

async function handleQuestion(chatId: number, question: string): Promise<void> {
  bot.sendMessage(chatId, '🤔 Buscando en tu Second Brain...');

  // First, search locally
  const localResults = searchContent(question, 5);

  // Then augment with Claude
  const answer = await augmentedSearch(question, localResults);

  bot.sendMessage(chatId, answer, { parse_mode: 'Markdown' }).catch(() => {
    // If Markdown fails, send as plain text
    bot.sendMessage(chatId, answer);
  });
}

// ============================================
// Utilities
// ============================================

function platformEmoji(platform: string): string {
  const emojis: Record<string, string> = {
    youtube: '🎬',
    twitter: '🐦',
    instagram: '📸',
    linkedin: '💼',
    web: '🌐',
    unknown: '❓',
  };
  return emojis[platform] || '📌';
}

function escapeMarkdown(text: string): string {
  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
}

export function getBotInstance(): TelegramBot | undefined {
  return bot;
}
