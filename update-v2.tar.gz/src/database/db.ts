import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { CONFIG, DEFAULT_CATEGORIES } from '../config/constants';
import { logger } from '../config/logger';
import type { ContentItem, Category, QueueItem, ContentStatus, QueueStatus, SearchResult } from '../types';

let db: Database.Database;

export function getDb(): Database.Database {
  if (!db) {
    // Ensure data directory exists
    const dbDir = path.dirname(CONFIG.databasePath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    db = new Database(CONFIG.databasePath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');

    logger.info(`Database connected: ${CONFIG.databasePath}`);
  }
  return db;
}

// ============================================
// Migrations
// ============================================

export function runMigrations(): void {
  const database = getDb();
  const migrationsDir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();

  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf-8');
    database.exec(sql);
    logger.info(`Migration applied: ${file}`);
  }

  // Seed default categories
  const insertCat = database.prepare(
    `INSERT OR IGNORE INTO categories (name, slug, description, color, icon) VALUES (?, ?, ?, ?, ?)`
  );
  for (const cat of DEFAULT_CATEGORIES) {
    insertCat.run(cat.name, cat.slug, cat.description, cat.color, cat.icon);
  }
  logger.info(`Default categories seeded (${DEFAULT_CATEGORIES.length} categories)`);
}

// ============================================
// Queue Operations
// ============================================

export function addToQueue(url: string, telegramChatId: string): QueueItem | null {
  const database = getDb();

  // Check if URL already exists in queue (pending/processing) or in content_items
  const existing = database.prepare(
    `SELECT id FROM queue_items WHERE url = ? AND status IN ('pending', 'processing')`
  ).get(url);
  if (existing) return null;

  const existingContent = database.prepare(
    `SELECT id FROM content_items WHERE url = ? AND status = 'processed'`
  ).get(url);
  if (existingContent) return null;

  const result = database.prepare(
    `INSERT INTO queue_items (url, telegram_chat_id) VALUES (?, ?)`
  ).run(url, telegramChatId);

  return database.prepare(`SELECT * FROM queue_items WHERE id = ?`).get(result.lastInsertRowid) as QueueItem;
}

export function getPendingQueueItems(limit: number = CONFIG.maxItemsPerBatch): QueueItem[] {
  return getDb().prepare(
    `SELECT * FROM queue_items WHERE status = 'pending' ORDER BY added_date ASC LIMIT ?`
  ).all(limit) as QueueItem[];
}

export function updateQueueStatus(id: number, status: QueueStatus, retryCount?: number, errorMsg?: string): void {
  if (retryCount !== undefined) {
    getDb().prepare(
      `UPDATE queue_items SET status = ?, retry_count = ? WHERE id = ?`
    ).run(status, retryCount, id);
  } else {
    getDb().prepare(`UPDATE queue_items SET status = ? WHERE id = ?`).run(status, id);
  }
}

// ============================================
// Content Operations
// ============================================

export function insertContent(data: Partial<ContentItem>): number {
  const result = getDb().prepare(`
    INSERT INTO content_items (url, title, source_platform, content_type, raw_content, transcription,
      summary, key_points, searchable_text, category_id, tags, extracted_urls, status, processed_date)
    VALUES (@url, @title, @source_platform, @content_type, @raw_content, @transcription,
      @summary, @key_points, @searchable_text, @category_id, @tags, @extracted_urls, @status, @processed_date)
  `).run({
    url: data.url,
    title: data.title || null,
    source_platform: data.source_platform || 'unknown',
    content_type: data.content_type || 'article',
    raw_content: data.raw_content || null,
    transcription: data.transcription || null,
    summary: data.summary || null,
    key_points: data.key_points || null,
    searchable_text: data.searchable_text || null,
    category_id: data.category_id || null,
    tags: data.tags || null,
    extracted_urls: data.extracted_urls || null,
    status: data.status || 'pending',
    processed_date: data.processed_date || null,
  });

  return result.lastInsertRowid as number;
}

export function updateContentStatus(id: number, status: ContentStatus, errorMsg?: string): void {
  if (errorMsg) {
    getDb().prepare(`UPDATE content_items SET status = ?, error_message = ? WHERE id = ?`).run(status, errorMsg, id);
  } else {
    getDb().prepare(`UPDATE content_items SET status = ? WHERE id = ?`).run(status, id);
  }
}

export function updateContentTags(id: number, tags: string[]): void {
  const tagsJson = JSON.stringify(tags);
  const item = getContentById(id);
  if (!item) return;

  // Update tags and rebuild searchable_text
  const searchableText = [
    item.title,
    item.summary,
    item.key_points ? (JSON.parse(item.key_points as string) as string[]).join('. ') : '',
    tags.join(' '),
  ].filter(Boolean).join(' | ');

  getDb().prepare(
    `UPDATE content_items SET tags = ?, searchable_text = ? WHERE id = ?`
  ).run(tagsJson, searchableText, id);
}

export function updateContentCategory(id: number, categoryId: number): void {
  getDb().prepare(`UPDATE content_items SET category_id = ? WHERE id = ?`).run(categoryId, id);
}

export function updateContentFull(id: number, data: { title?: string; summary?: string; tags?: string[]; category_id?: number }): void {
  const item = getContentById(id);
  if (!item) return;

  const title = data.title || item.title;
  const summary = data.summary || item.summary;
  const tags = data.tags || (item.tags ? JSON.parse(item.tags as string) : []);
  const categoryId = data.category_id || item.category_id;

  const searchableText = [title, summary, tags.join(' ')].filter(Boolean).join(' | ');

  getDb().prepare(`
    UPDATE content_items SET title = ?, summary = ?, tags = ?, category_id = ?, searchable_text = ? WHERE id = ?
  `).run(title, summary, JSON.stringify(tags), categoryId, searchableText, id);
}

export function getFailedQueueItems(): QueueItem[] {
  return getDb().prepare(
    `SELECT * FROM queue_items WHERE status = 'failed' ORDER BY added_date DESC`
  ).all() as QueueItem[];
}

export function getQueueItemById(id: number): QueueItem | undefined {
  return getDb().prepare(`SELECT * FROM queue_items WHERE id = ?`).get(id) as QueueItem | undefined;
}

// ============================================
// Category Operations
// ============================================

export function getAllCategories(): Category[] {
  return getDb().prepare(`SELECT * FROM categories ORDER BY name`).all() as Category[];
}

export function getCategoryBySlug(slug: string): Category | undefined {
  return getDb().prepare(`SELECT * FROM categories WHERE slug = ?`).get(slug) as Category | undefined;
}

export function getCategoryByName(name: string): Category | undefined {
  return getDb().prepare(
    `SELECT * FROM categories WHERE LOWER(name) = LOWER(?)`
  ).get(name) as Category | undefined;
}

export function addCategory(name: string, slug: string, description?: string, color?: string, icon?: string): Category {
  getDb().prepare(
    `INSERT OR IGNORE INTO categories (name, slug, description, color, icon) VALUES (?, ?, ?, ?, ?)`
  ).run(name, slug, description || '', color || '#6B7280', icon || '📌');
  return getCategoryBySlug(slug)!;
}

// ============================================
// Search Operations (FTS5)
// ============================================

export function searchContent(query: string, limit: number = 10, categorySlug?: string): SearchResult[] {
  const database = getDb();

  // Sanitize query for FTS5
  const ftsQuery = query
    .replace(/[^\w\sáéíóúñü]/gi, '')
    .split(/\s+/)
    .filter(w => w.length > 1)
    .map(w => `"${w}"`)
    .join(' OR ');

  if (!ftsQuery) return [];

  let sql = `
    SELECT
      ci.*,
      c.name as category_name,
      rank
    FROM fts_content
    JOIN content_items ci ON ci.id = fts_content.rowid
    LEFT JOIN categories c ON ci.category_id = c.id
    WHERE fts_content MATCH ?
  `;
  const params: any[] = [ftsQuery];

  if (categorySlug) {
    sql += ` AND c.slug = ?`;
    params.push(categorySlug);
  }

  sql += ` ORDER BY rank LIMIT ?`;
  params.push(limit);

  const rows = database.prepare(sql).all(...params) as any[];

  return rows.map((row, idx) => ({
    item: row as ContentItem,
    category_name: row.category_name || 'Sin categoría',
    rank: idx + 1,
    snippet: (row.summary || '').substring(0, 200),
  }));
}

// ============================================
// Content Retrieval
// ============================================

export function getContentByCategory(categorySlug?: string, page: number = 1, limit: number = 20): { items: any[]; total: number } {
  const database = getDb();
  const offset = (page - 1) * limit;

  let countSql = `SELECT COUNT(*) as total FROM content_items ci WHERE ci.status = 'processed'`;
  let sql = `
    SELECT ci.*, c.name as category_name, c.slug as category_slug, c.color as category_color, c.icon as category_icon
    FROM content_items ci
    LEFT JOIN categories c ON ci.category_id = c.id
    WHERE ci.status = 'processed'
  `;
  const params: any[] = [];

  if (categorySlug && categorySlug !== 'all') {
    countSql += ` AND ci.category_id = (SELECT id FROM categories WHERE slug = ?)`;
    sql += ` AND c.slug = ?`;
    params.push(categorySlug);
  }

  const total = (database.prepare(countSql).get(...params) as any).total;

  sql += ` ORDER BY ci.added_date DESC LIMIT ? OFFSET ?`;
  const items = database.prepare(sql).all(...params, limit, offset);

  return { items, total };
}

export function getContentById(id: number): ContentItem | undefined {
  return getDb().prepare(`SELECT * FROM content_items WHERE id = ?`).get(id) as ContentItem | undefined;
}

export function getStats(): any {
  const database = getDb();
  const total = (database.prepare(`SELECT COUNT(*) as c FROM content_items WHERE status = 'processed'`).get() as any).c;
  const pending = (database.prepare(`SELECT COUNT(*) as c FROM queue_items WHERE status = 'pending'`).get() as any).c;
  const byCategory = database.prepare(`
    SELECT c.name, c.slug, c.color, c.icon, COUNT(ci.id) as count
    FROM categories c
    LEFT JOIN content_items ci ON ci.category_id = c.id AND ci.status = 'processed'
    GROUP BY c.id
    ORDER BY count DESC
  `).all();
  const byPlatform = database.prepare(`
    SELECT source_platform, COUNT(*) as count
    FROM content_items WHERE status = 'processed'
    GROUP BY source_platform
  `).all();
  const recent = database.prepare(`
    SELECT ci.title, ci.url, ci.added_date, c.name as category_name, c.icon
    FROM content_items ci
    LEFT JOIN categories c ON ci.category_id = c.id
    WHERE ci.status = 'processed'
    ORDER BY ci.added_date DESC LIMIT 5
  `).all();

  return { total, pending, byCategory, byPlatform, recent };
}
