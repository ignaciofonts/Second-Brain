// ============================================
// Second Brain - Type Definitions
// ============================================

export type ContentType = 'video' | 'article' | 'social_post' | 'image_carousel' | 'audio';
export type ContentStatus = 'pending' | 'processing' | 'processed' | 'failed';
export type QueueStatus = 'pending' | 'processing' | 'completed' | 'failed';
export type SourcePlatform = 'youtube' | 'twitter' | 'instagram' | 'linkedin' | 'web' | 'unknown';

export interface ContentItem {
  id: number;
  url: string;
  title: string | null;
  source_platform: SourcePlatform;
  content_type: ContentType;
  raw_content: string | null;
  transcription: string | null;
  summary: string | null;
  key_points: string | null;       // JSON array of strings
  searchable_text: string | null;
  category_id: number | null;
  tags: string | null;             // JSON array of strings
  extracted_urls: string | null;   // JSON array of {url, context}
  added_date: string;
  processed_date: string | null;
  status: ContentStatus;
  error_message: string | null;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  color: string;
  icon: string;
}

export interface QueueItem {
  id: number;
  url: string;
  telegram_chat_id: string;
  added_date: string;
  status: QueueStatus;
  retry_count: number;
}

export interface ExtractedUrl {
  url: string;
  context: string;
}

export interface ClaudeProcessingResult {
  title: string;
  summary: string;
  key_points: string[];
  category: string;
  tags: string[];
  extracted_urls: ExtractedUrl[];
}

export interface FetchedContent {
  url: string;
  platform: SourcePlatform;
  contentType: ContentType;
  title: string;
  textContent: string;
  audioPath?: string;    // For videos that need transcription
  imageUrls?: string[];  // URLs of images in the post
  imagePaths?: string[]; // Local paths of downloaded images
}

export interface SearchResult {
  item: ContentItem;
  category_name: string;
  rank: number;
  snippet: string;
}
