-- ============================================
-- Second Brain - Full-Text Search (FTS5)
-- ============================================

CREATE VIRTUAL TABLE IF NOT EXISTS fts_content USING fts5(
  title,
  summary,
  key_points,
  searchable_text,
  tags,
  content='content_items',
  content_rowid='id',
  tokenize='unicode61 remove_diacritics 2'
);

-- Triggers to keep FTS in sync
CREATE TRIGGER IF NOT EXISTS content_ai AFTER INSERT ON content_items
WHEN NEW.status = 'processed'
BEGIN
  INSERT INTO fts_content(rowid, title, summary, key_points, searchable_text, tags)
  VALUES (NEW.id, NEW.title, NEW.summary, NEW.key_points, NEW.searchable_text, NEW.tags);
END;

CREATE TRIGGER IF NOT EXISTS content_au AFTER UPDATE ON content_items
WHEN NEW.status = 'processed'
BEGIN
  DELETE FROM fts_content WHERE rowid = OLD.id;
  INSERT INTO fts_content(rowid, title, summary, key_points, searchable_text, tags)
  VALUES (NEW.id, NEW.title, NEW.summary, NEW.key_points, NEW.searchable_text, NEW.tags);
END;

CREATE TRIGGER IF NOT EXISTS content_ad AFTER DELETE ON content_items BEGIN
  DELETE FROM fts_content WHERE rowid = OLD.id;
END;
