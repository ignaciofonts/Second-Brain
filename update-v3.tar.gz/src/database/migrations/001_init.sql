-- ============================================
-- Second Brain - Initial Schema
-- ============================================

CREATE TABLE IF NOT EXISTS categories (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT UNIQUE NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  description TEXT,
  color       TEXT DEFAULT '#6B7280',
  icon        TEXT DEFAULT '📌',
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS content_items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  url             TEXT UNIQUE NOT NULL,
  title           TEXT,
  source_platform TEXT CHECK(source_platform IN ('youtube','twitter','instagram','linkedin','web','unknown')) DEFAULT 'unknown',
  content_type    TEXT CHECK(content_type IN ('video','article','social_post','image_carousel','audio')) DEFAULT 'article',
  raw_content     TEXT,
  transcription   TEXT,
  summary         TEXT,
  key_points      TEXT,          -- JSON array of strings
  searchable_text TEXT,          -- Combined text for FTS
  category_id     INTEGER REFERENCES categories(id),
  tags            TEXT,          -- JSON array
  extracted_urls  TEXT,          -- JSON array of {url, context}
  added_date      DATETIME DEFAULT CURRENT_TIMESTAMP,
  processed_date  DATETIME,
  status          TEXT CHECK(status IN ('pending','processing','processed','failed')) DEFAULT 'pending',
  error_message   TEXT
);

CREATE TABLE IF NOT EXISTS queue_items (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  url              TEXT NOT NULL,
  telegram_chat_id TEXT,
  added_date       DATETIME DEFAULT CURRENT_TIMESTAMP,
  status           TEXT CHECK(status IN ('pending','processing','completed','failed')) DEFAULT 'pending',
  retry_count      INTEGER DEFAULT 0
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_content_status ON content_items(status);
CREATE INDEX IF NOT EXISTS idx_content_category ON content_items(category_id);
CREATE INDEX IF NOT EXISTS idx_content_platform ON content_items(source_platform);
CREATE INDEX IF NOT EXISTS idx_content_date ON content_items(added_date DESC);
CREATE INDEX IF NOT EXISTS idx_queue_status ON queue_items(status);
