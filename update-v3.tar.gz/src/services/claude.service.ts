import Anthropic from '@anthropic-ai/sdk';
import fs from 'fs';
import { CONFIG, DEFAULT_CATEGORIES } from '../config/constants';
import { logger } from '../config/logger';
import type { ClaudeProcessingResult, SearchResult } from '../types';

const anthropic = new Anthropic({ apiKey: CONFIG.anthropicKey });

const CATEGORY_NAMES = DEFAULT_CATEGORIES.map(c => c.name).join(', ');

/**
 * Process fetched content: summarize, categorize, extract tags and URLs
 */
export async function processContent(
  textContent: string,
  url: string,
  platform: string,
  title?: string
): Promise<ClaudeProcessingResult> {
  // Truncate very long content to avoid excessive token usage
  const truncatedContent = textContent.substring(0, 12000);

  const prompt = `Eres un asistente de gestión de conocimiento personal ("Second Brain").
Analiza el siguiente contenido y devuelve un JSON con esta estructura exacta:

{
  "title": "Título descriptivo y conciso del contenido",
  "summary": "Resumen en español de 3-5 frases que capture las ideas principales. Debe ser útil para recordar de qué trata sin releer el original.",
  "key_points": ["punto clave 1", "punto clave 2", "punto clave 3"],
  "category": "Una de estas categorías: ${CATEGORY_NAMES}",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
  "extracted_urls": [{"url": "https://...", "context": "Descripción breve de a qué se refiere este enlace"}]
}

Reglas:
- El resumen debe estar en ESPAÑOL, independientemente del idioma original.
- Los tags deben ser palabras sueltas o frases cortas en español, relevantes para búsquedas futuras.
- Elige la categoría que mejor encaje. Si ninguna encaja bien, usa "Otro".
- extracted_urls: solo incluye URLs mencionadas explícitamente en el contenido (no la URL fuente).
- Si no hay URLs mencionadas en el contenido, extracted_urls debe ser un array vacío.
- Responde SOLO con el JSON, sin texto adicional, sin markdown, sin backticks.

Fuente: ${platform}
URL: ${url}
${title ? `Título original: ${title}` : ''}

Contenido:
${truncatedContent}`;

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    });

    const text = response.content[0].type === 'text' ? response.content[0].text : '';

    // Parse JSON (handle potential markdown wrapping)
    const jsonStr = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const result = JSON.parse(jsonStr) as ClaudeProcessingResult;

    // Validate required fields
    if (!result.title || !result.summary || !result.category) {
      throw new Error('Missing required fields in Claude response');
    }

    logger.info(`Content processed: "${result.title}" -> ${result.category}`);
    return result;
  } catch (err) {
    logger.error(`Claude processing failed: ${err}`);
    throw err;
  }
}

/**
 * Process images: use Claude Vision to analyze image content
 */
export async function processImage(
  imagePaths: string[],
  url: string,
  platform: string,
  textHint?: string
): Promise<ClaudeProcessingResult> {
  logger.info(`Processing ${imagePaths.length} image(s) with Claude Vision...`);

  // Build content blocks: images + text prompt
  const contentBlocks: any[] = [];

  for (const imgPath of imagePaths.slice(0, 3)) { // Max 3 images
    try {
      const imageData = fs.readFileSync(imgPath);
      const base64 = imageData.toString('base64');
      const ext = imgPath.split('.').pop()?.toLowerCase() || 'jpeg';
      const mediaType = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';

      contentBlocks.push({
        type: 'image',
        source: {
          type: 'base64',
          media_type: mediaType,
          data: base64,
        },
      });
    } catch (err) {
      logger.error(`Failed to read image ${imgPath}: ${err}`);
    }
  }

  if (contentBlocks.length === 0) {
    throw new Error('No images could be loaded for vision processing');
  }

  contentBlocks.push({
    type: 'text',
    text: `Eres un asistente de gestión de conocimiento personal ("Second Brain").
Analiza la(s) imagen(es) anterior(es) y devuelve un JSON con esta estructura exacta:

{
  "title": "Título descriptivo y conciso del contenido de la imagen",
  "summary": "Resumen en español de 3-5 frases describiendo qué muestra la imagen, qué información contiene, y por qué podría ser útil guardarla.",
  "key_points": ["punto clave 1", "punto clave 2", "punto clave 3"],
  "category": "Una de estas categorías: ${CATEGORY_NAMES}",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
  "extracted_urls": []
}

${textHint ? `Contexto adicional del post: ${textHint}` : ''}
Fuente: ${platform}
URL: ${url}

Reglas:
- Si la imagen contiene texto, transcríbelo e inclúyelo en el resumen.
- Si es una infografía, diagrama o tutorial, extrae los pasos o la información clave.
- El resumen debe estar en ESPAÑOL.
- Los tags deben ser palabras o frases cortas en español.
- Responde SOLO con el JSON, sin texto adicional, sin markdown, sin backticks.`,
  });

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: contentBlocks }],
    });

    const text = response.content[0].type === 'text' ? response.content[0].text : '';
    const jsonStr = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const result = JSON.parse(jsonStr) as ClaudeProcessingResult;

    if (!result.title || !result.summary || !result.category) {
      throw new Error('Missing required fields in Claude Vision response');
    }

    logger.info(`Image processed: "${result.title}" -> ${result.category}`);
    return result;
  } catch (err) {
    logger.error(`Claude Vision processing failed: ${err}`);
    throw err;
  }
}

/**
 * Augmented search: user asks a question, we provide local context + Claude's knowledge
 */
export async function augmentedSearch(
  userQuery: string,
  localResults: SearchResult[]
): Promise<string> {
  const hasLocalResults = localResults.length > 0;

  let contextBlock = '';
  if (hasLocalResults) {
    contextBlock = localResults
      .map((r, i) => {
        const tags = r.item.tags ? JSON.parse(r.item.tags).join(', ') : '';
        return `${i + 1}. "${r.item.title}" [${r.category_name}]
   Resumen: ${r.item.summary}
   Tags: ${tags}
   URL: ${r.item.url}`;
      })
      .join('\n\n');
  }

  const prompt = `Eres el asistente de un "Second Brain" personal. El usuario te hace una pregunta y tienes acceso a contenido que ha ido guardando.

${hasLocalResults ? `CONTENIDO GUARDADO POR EL USUARIO (relevante a su pregunta):
${contextBlock}

` : 'No se encontró contenido guardado directamente relacionado con esta pregunta.\n\n'}Pregunta del usuario: "${userQuery}"

Instrucciones:
1. ${hasLocalResults
    ? 'PRIMERO responde basándote en el contenido guardado del usuario. Referencia los items por su título.'
    : 'Indica que no hay contenido guardado sobre este tema.'}
2. Si es útil, complementa con tu conocimiento general, pero distingue claramente qué viene de "su colección" vs tu conocimiento.
3. Responde en español, de forma concisa y útil.
4. Si el usuario pregunta por una "lista" o "herramientas", organiza la respuesta de forma práctica.
5. No inventes contenido que el usuario no haya guardado. Sé honesto sobre lo que hay y lo que no.`;

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });

    return response.content[0].type === 'text' ? response.content[0].text : 'No pude generar una respuesta.';
  } catch (err) {
    logger.error(`Augmented search failed: ${err}`);
    return 'Lo siento, hubo un error al procesar tu consulta. Inténtalo de nuevo.';
  }
}
