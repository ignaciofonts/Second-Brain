import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import * as cheerio from 'cheerio';
import { CONFIG } from '../config/constants';
import { logger } from '../config/logger';
import { detectPlatform } from '../utils/url-detector';
import type { FetchedContent, SourcePlatform } from '../types';

const execAsync = promisify(exec);

// Ensure temp directory exists
if (!fs.existsSync(CONFIG.tempDir)) {
  fs.mkdirSync(CONFIG.tempDir, { recursive: true });
}

/**
 * Download an image from URL to local temp path
 */
async function downloadImage(imageUrl: string, filename: string): Promise<string | null> {
  try {
    const response = await fetch(imageUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
    });
    if (!response.ok) return null;

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.startsWith('image/')) return null;

    const buffer = Buffer.from(await response.arrayBuffer());
    const ext = contentType.includes('png') ? '.png' : contentType.includes('webp') ? '.webp' : '.jpg';
    const filePath = path.join(CONFIG.tempDir, `${filename}${ext}`);
    fs.writeFileSync(filePath, buffer);
    logger.info(`Image downloaded: ${filePath} (${(buffer.length / 1024).toFixed(1)}KB)`);
    return filePath;
  } catch (err) {
    logger.debug(`Failed to download image ${imageUrl}: ${err}`);
    return null;
  }
}

/**
 * Try to get thumbnail/image from yt-dlp metadata
 */
async function downloadThumbnail(url: string, prefix: string): Promise<string | null> {
  try {
    const { stdout } = await execAsync(
      `yt-dlp --get-thumbnail --no-download "${url}" 2>/dev/null`,
      { timeout: 15000 }
    );
    const thumbUrl = stdout.trim();
    if (thumbUrl && thumbUrl.startsWith('http')) {
      return downloadImage(thumbUrl, prefix);
    }
  } catch {}
  return null;
}

/**
 * Main entry point: fetch content from any supported URL
 */
export async function fetchContent(url: string): Promise<FetchedContent> {
  const info = detectPlatform(url);

  switch (info.platform) {
    case 'youtube':
      return fetchYouTube(url, info.videoId);
    case 'twitter':
      return fetchTwitter(url);
    case 'instagram':
      return fetchInstagram(url);
    case 'linkedin':
      return fetchLinkedIn(url);
    default:
      return fetchGenericWeb(url);
  }
}

// ============================================
// YouTube: download audio for transcription
// ============================================

async function fetchYouTube(url: string, videoId?: string): Promise<FetchedContent> {
  const id = videoId || 'unknown';
  const audioPath = path.join(CONFIG.tempDir, `${id}.mp3`);

  logger.info(`Fetching YouTube video: ${url}`);

  // First try to get subtitles/captions (free, no Whisper needed)
  try {
    const { stdout: subOut } = await execAsync(
      `yt-dlp --write-auto-sub --sub-lang es,en --skip-download --sub-format vtt -o "${CONFIG.tempDir}/${id}" "${url}" 2>&1 || true`,
      { timeout: 60000 }
    );

    // Check if subtitle file was downloaded
    const subFiles = fs.readdirSync(CONFIG.tempDir).filter(f => f.startsWith(id) && (f.endsWith('.vtt') || f.endsWith('.srt')));
    if (subFiles.length > 0) {
      const subContent = fs.readFileSync(path.join(CONFIG.tempDir, subFiles[0]), 'utf-8');
      const cleanedSubs = cleanSubtitles(subContent);

      // Get title
      const title = await getYouTubeTitle(url);

      // Cleanup sub files
      for (const f of subFiles) {
        fs.unlinkSync(path.join(CONFIG.tempDir, f));
      }

      return {
        url,
        platform: 'youtube',
        contentType: 'video',
        title,
        textContent: cleanedSubs,
      };
    }
  } catch (err) {
    logger.debug('No subtitles available, falling back to audio download');
  }

  // Fallback: download audio for Whisper transcription
  try {
    await execAsync(
      `yt-dlp -f "bestaudio[ext=m4a]/bestaudio" --extract-audio --audio-format mp3 --audio-quality 5 -o "${audioPath}" "${url}"`,
      { timeout: 300000 }
    );

    const title = await getYouTubeTitle(url);

    return {
      url,
      platform: 'youtube',
      contentType: 'video',
      title,
      textContent: '',
      audioPath: fs.existsSync(audioPath) ? audioPath : undefined,
    };
  } catch (err) {
    logger.error(`Failed to download YouTube audio: ${err}`);
    // Final fallback: just get the title and metadata
    const title = await getYouTubeTitle(url);
    return {
      url,
      platform: 'youtube',
      contentType: 'video',
      title,
      textContent: `[Video de YouTube: ${title}] - No se pudo extraer el contenido.`,
    };
  }
}

async function getYouTubeTitle(url: string): Promise<string> {
  try {
    const { stdout } = await execAsync(`yt-dlp --get-title "${url}"`, { timeout: 30000 });
    return stdout.trim();
  } catch {
    return 'Video de YouTube (sin título)';
  }
}

function cleanSubtitles(vttContent: string): string {
  return vttContent
    .replace(/WEBVTT[\s\S]*?\n\n/, '')             // Remove VTT header
    .replace(/\d{2}:\d{2}:\d{2}\.\d{3} --> [\s\S]*?\n/g, '') // Remove timestamps
    .replace(/<[^>]+>/g, '')                         // Remove HTML tags
    .replace(/\n{3,}/g, '\n\n')                      // Collapse blank lines
    .replace(/^[\s\n]+|[\s\n]+$/g, '')               // Trim
    .split('\n')
    .filter((line, i, arr) => line !== arr[i - 1])   // Remove consecutive duplicates
    .join('\n');
}

// ============================================
// Twitter/X
// ============================================

async function fetchTwitter(url: string): Promise<FetchedContent> {
  logger.info(`Fetching Twitter/X: ${url}`);

  // Use nitter or similar proxy, or try direct fetch
  try {
    // Try using a nitter instance for public tweets
    const nitterUrl = url.replace('twitter.com', 'nitter.net').replace('x.com', 'nitter.net');
    const response = await fetch(nitterUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; SecondBrain/1.0)' },
    });
    const html = await response.text();
    const $ = cheerio.load(html);

    const tweetText = $('.tweet-content').first().text().trim();
    const username = $('.username').first().text().trim();

    if (tweetText) {
      return {
        url,
        platform: 'twitter',
        contentType: 'social_post',
        title: `Tweet de ${username}`,
        textContent: tweetText,
      };
    }
  } catch (err) {
    logger.debug(`Nitter fetch failed, trying direct method`);
  }

  // Fallback: use yt-dlp for tweet content if it contains video
  try {
    const { stdout } = await execAsync(
      `yt-dlp --dump-json --no-download "${url}" 2>/dev/null || echo "{}"`,
      { timeout: 30000 }
    );
    const data = JSON.parse(stdout);
    if (data.description) {
      return {
        url,
        platform: 'twitter',
        contentType: data.duration ? 'video' : 'social_post',
        title: data.title || `Tweet`,
        textContent: data.description || '',
        audioPath: data.duration ? undefined : undefined, // Could download audio if video
      };
    }
  } catch {}

  return {
    url,
    platform: 'twitter',
    contentType: 'social_post',
    title: 'Post de X/Twitter',
    textContent: `[Post de X/Twitter] - URL: ${url}. Contenido no extraído automáticamente. Puedes añadir notas manualmente.`,
  };
}

// ============================================
// Instagram
// ============================================

async function fetchInstagram(url: string): Promise<FetchedContent> {
  logger.info(`Fetching Instagram: ${url}`);

  // Try yt-dlp first (works for reels and public posts)
  try {
    const { stdout } = await execAsync(
      `yt-dlp --dump-json --no-download "${url}" 2>/dev/null`,
      { timeout: 30000 }
    );
    const data = JSON.parse(stdout);

    const isVideo = url.includes('/reel/') || url.includes('/tv/') || data.duration;

    if (isVideo && data.duration) {
      // Download audio for transcription
      const audioPath = path.join(CONFIG.tempDir, `ig_${Date.now()}.mp3`);
      await execAsync(
        `yt-dlp -f "bestaudio" --extract-audio --audio-format mp3 -o "${audioPath}" "${url}"`,
        { timeout: 120000 }
      );

      return {
        url,
        platform: 'instagram',
        contentType: 'video',
        title: data.title || data.description?.substring(0, 80) || 'Reel de Instagram',
        textContent: data.description || '',
        audioPath: fs.existsSync(audioPath) ? audioPath : undefined,
      };
    }

    // For image posts, try to download the thumbnail/image
    const imagePaths: string[] = [];
    if (!isVideo && data.thumbnail) {
      const imgPath = await downloadImage(data.thumbnail, `ig_img_${Date.now()}`);
      if (imgPath) imagePaths.push(imgPath);
    }

    return {
      url,
      platform: 'instagram',
      contentType: isVideo ? 'video' : imagePaths.length > 0 ? 'image_carousel' : 'social_post',
      title: data.title || 'Post de Instagram',
      textContent: data.description || '',
      imagePaths: imagePaths.length > 0 ? imagePaths : undefined,
    };
  } catch (err) {
    logger.debug(`yt-dlp failed for Instagram: ${err}`);
  }

  // Fallback: fetch HTML and extract og:image
  logger.info(`Trying HTML fallback for Instagram image...`);
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      },
      redirect: 'follow',
    });
    const html = await response.text();
    const $ = cheerio.load(html);

    const ogImage = $('meta[property="og:image"]').attr('content');
    const ogTitle = $('meta[property="og:title"]').attr('content') || '';
    const ogDesc = $('meta[property="og:description"]').attr('content') || '';
    const title = $('title').text().trim();

    const imagePaths: string[] = [];
    if (ogImage) {
      logger.info(`Found og:image for Instagram: ${ogImage.substring(0, 80)}...`);
      const imgPath = await downloadImage(ogImage, `ig_og_${Date.now()}`);
      if (imgPath) imagePaths.push(imgPath);
    }

    return {
      url,
      platform: 'instagram',
      contentType: imagePaths.length > 0 ? 'image_carousel' : 'social_post',
      title: ogTitle || title || 'Post de Instagram',
      textContent: ogDesc || '',
      imagePaths: imagePaths.length > 0 ? imagePaths : undefined,
    };
  } catch (err) {
    logger.debug(`HTML fallback failed for Instagram: ${err}`);
  }

  return {
    url,
    platform: 'instagram',
    contentType: 'social_post',
    title: 'Post de Instagram',
    textContent: '',
  };
}

// ============================================
// LinkedIn
// ============================================

async function fetchLinkedIn(url: string): Promise<FetchedContent> {
  logger.info(`Fetching LinkedIn: ${url}`);

  // LinkedIn is heavily protected; try basic fetch
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });
    const html = await response.text();
    const $ = cheerio.load(html);

    const title = $('title').text().trim() || $('h1').first().text().trim();
    const description = $('meta[name="description"]').attr('content') || '';
    const articleText = $('article').text().trim() || $('.article-content').text().trim();

    return {
      url,
      platform: 'linkedin',
      contentType: 'article',
      title: title || 'Post de LinkedIn',
      textContent: articleText || description || `[Post de LinkedIn] - ${title}`,
    };
  } catch (err) {
    logger.debug(`LinkedIn fetch failed: ${err}`);
  }

  return {
    url,
    platform: 'linkedin',
    contentType: 'article',
    title: 'Post de LinkedIn',
    textContent: `[Post de LinkedIn] - URL: ${url}. Contenido no extraído automáticamente. LinkedIn requiere autenticación.`,
  };
}

// ============================================
// Generic Web
// ============================================

async function fetchGenericWeb(url: string): Promise<FetchedContent> {
  logger.info(`Fetching generic web: ${url}`);

  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });
    const html = await response.text();
    const $ = cheerio.load(html);

    // Remove nav, footer, scripts, styles
    $('nav, footer, script, style, .sidebar, .comments, .ads').remove();

    const title = $('title').text().trim()
      || $('h1').first().text().trim()
      || $('meta[property="og:title"]').attr('content')
      || '';

    // Extract main content
    const mainContent = $('article').text().trim()
      || $('main').text().trim()
      || $('[role="main"]').text().trim()
      || $('body').text().trim();

    // Clean up whitespace
    const cleanContent = mainContent.replace(/\s+/g, ' ').trim().substring(0, 15000);

    // Try to download main image if text content is very short
    const imagePaths: string[] = [];
    if (cleanContent.length < 100) {
      const ogImage = $('meta[property="og:image"]').attr('content')
        || $('meta[name="twitter:image"]').attr('content');
      if (ogImage) {
        const imgUrl = ogImage.startsWith('http') ? ogImage : new URL(ogImage, url).href;
        const imgPath = await downloadImage(imgUrl, `web_img_${Date.now()}`);
        if (imgPath) imagePaths.push(imgPath);
      }
    }

    return {
      url,
      platform: 'web',
      contentType: imagePaths.length > 0 && cleanContent.length < 100 ? 'image_carousel' : 'article',
      title: title || url,
      textContent: cleanContent,
      imagePaths: imagePaths.length > 0 ? imagePaths : undefined,
    };
  } catch (err) {
    logger.error(`Failed to fetch web page: ${err}`);
    return {
      url,
      platform: 'web',
      contentType: 'article',
      title: url,
      textContent: `[Página web] - No se pudo extraer el contenido de ${url}`,
    };
  }
}
