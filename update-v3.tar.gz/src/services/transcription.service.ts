import OpenAI from 'openai';
import fs from 'fs';
import path from 'path';
import { CONFIG } from '../config/constants';
import { logger } from '../config/logger';

const openai = new OpenAI({ apiKey: CONFIG.openaiKey });

// Whisper API has a 25MB file size limit
const MAX_FILE_SIZE = 25 * 1024 * 1024;

/**
 * Transcribe an audio file using OpenAI Whisper API
 */
export async function transcribeAudio(audioPath: string): Promise<string> {
  if (!fs.existsSync(audioPath)) {
    throw new Error(`Audio file not found: ${audioPath}`);
  }

  const stats = fs.statSync(audioPath);
  logger.info(`Transcribing audio: ${audioPath} (${(stats.size / 1024 / 1024).toFixed(1)}MB)`);

  // If file is too large, split it
  if (stats.size > MAX_FILE_SIZE) {
    return transcribeLargeFile(audioPath);
  }

  try {
    const transcription = await openai.audio.transcriptions.create({
      file: fs.createReadStream(audioPath),
      model: 'whisper-1',
      language: 'es', // Default to Spanish, Whisper auto-detects anyway
      response_format: 'text',
    });

    logger.info(`Transcription complete: ${transcription.substring(0, 100)}...`);

    // Cleanup temp file
    cleanupFile(audioPath);

    return transcription;
  } catch (err) {
    logger.error(`Whisper transcription failed: ${err}`);
    cleanupFile(audioPath);
    throw err;
  }
}

/**
 * For files > 25MB, split into chunks and transcribe each
 */
async function transcribeLargeFile(audioPath: string): Promise<string> {
  const { exec } = require('child_process');
  const { promisify } = require('util');
  const execAsync = promisify(exec);

  const baseName = path.basename(audioPath, path.extname(audioPath));
  const chunkDir = path.join(CONFIG.tempDir, `chunks_${baseName}`);
  fs.mkdirSync(chunkDir, { recursive: true });

  try {
    // Split into 10-minute chunks using ffmpeg
    await execAsync(
      `ffmpeg -i "${audioPath}" -f segment -segment_time 600 -c copy "${chunkDir}/chunk_%03d.mp3"`,
      { timeout: 120000 }
    );

    const chunks = fs.readdirSync(chunkDir).filter(f => f.endsWith('.mp3')).sort();
    const transcriptions: string[] = [];

    for (const chunk of chunks) {
      const chunkPath = path.join(chunkDir, chunk);
      logger.info(`Transcribing chunk: ${chunk}`);

      const transcription = await openai.audio.transcriptions.create({
        file: fs.createReadStream(chunkPath),
        model: 'whisper-1',
        language: 'es',
        response_format: 'text',
      });

      transcriptions.push(transcription);
    }

    // Cleanup
    fs.rmSync(chunkDir, { recursive: true, force: true });
    cleanupFile(audioPath);

    return transcriptions.join('\n\n');
  } catch (err) {
    fs.rmSync(chunkDir, { recursive: true, force: true });
    cleanupFile(audioPath);
    throw err;
  }
}

function cleanupFile(filePath: string): void {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch {
    // Ignore cleanup errors
  }
}
