import type { SourcePlatform, ContentType } from '../types';

interface UrlInfo {
  platform: SourcePlatform;
  contentType: ContentType;
  videoId?: string;
}

export function detectPlatform(url: string): UrlInfo {
  const u = url.toLowerCase();

  // YouTube
  if (u.includes('youtube.com/watch') || u.includes('youtu.be/') || u.includes('youtube.com/shorts')) {
    const videoId = extractYouTubeId(url);
    return { platform: 'youtube', contentType: 'video', videoId };
  }

  // Twitter / X
  if (u.includes('twitter.com/') || u.includes('x.com/')) {
    return { platform: 'twitter', contentType: 'social_post' };
  }

  // Instagram
  if (u.includes('instagram.com/')) {
    if (u.includes('/reel/') || u.includes('/tv/')) {
      return { platform: 'instagram', contentType: 'video' };
    }
    return { platform: 'instagram', contentType: 'social_post' };
  }

  // LinkedIn
  if (u.includes('linkedin.com/')) {
    return { platform: 'linkedin', contentType: 'article' };
  }

  // Generic web
  return { platform: 'web', contentType: 'article' };
}

function extractYouTubeId(url: string): string | undefined {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return undefined;
}

export function isValidUrl(text: string): boolean {
  try {
    const url = new URL(text.trim());
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

export function cleanUrl(url: string): string {
  // Remove tracking parameters
  try {
    const u = new URL(url.trim());
    const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'fbclid', 'gclid', 'ref', 'si'];
    for (const param of trackingParams) {
      u.searchParams.delete(param);
    }
    return u.toString();
  } catch {
    return url.trim();
  }
}
