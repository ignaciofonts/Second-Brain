import { fetchContent } from '../services/content-fetch.service';
import { transcribeAudio } from '../services/transcription.service';
import { processContent, processImage } from '../services/claude.service';
import * as db from '../database/db';
import { logger } from '../config/logger';
import { cleanUrl } from '../utils/url-detector';
import type { QueueItem } from '../types';
import fs from 'fs';

/**
 * Process a single queue item through the full pipeline:
 * Fetch -> Transcribe (if needed) -> Claude Processing -> Store
 */
export async function processQueueItem(queueItem: QueueItem): Promise<void> {
  const url = cleanUrl(queueItem.url);
  logger.info(`Processing queue item #${queueItem.id}: ${url}`);

  // Mark as processing
  db.updateQueueStatus(queueItem.id, 'processing');

  try {
    // Step 1: Fetch content from the URL
    logger.info(`Step 1: Fetching content...`);
    const fetched = await fetchContent(url);

    // Step 2: Transcribe audio if present
    let fullText = fetched.textContent;
    let transcription: string | null = null;

    if (fetched.audioPath) {
      logger.info(`Step 2: Transcribing audio...`);
      transcription = await transcribeAudio(fetched.audioPath);
      fullText = transcription;
    }

    // Step 2.5: If no text but images available, use Claude Vision
    if ((!fullText || fullText.trim().length < 20) && fetched.imagePaths && fetched.imagePaths.length > 0) {
      logger.info(`No text but ${fetched.imagePaths.length} image(s) found. Using Claude Vision...`);

      try {
        const claudeResult = await processImage(
          fetched.imagePaths,
          url,
          fetched.platform,
          fetched.title
        );

        let category = db.getCategoryByName(claudeResult.category);
        if (!category) category = db.getCategoryBySlug('otro');

        const searchableText = [
          claudeResult.title, claudeResult.summary,
          claudeResult.key_points.join('. '), claudeResult.tags.join(' '),
        ].filter(Boolean).join(' | ');

        db.insertContent({
          url,
          title: claudeResult.title,
          source_platform: fetched.platform,
          content_type: 'image_carousel',
          raw_content: `[Imagen analizada por Vision] ${claudeResult.summary}`,
          summary: claudeResult.summary,
          key_points: JSON.stringify(claudeResult.key_points),
          searchable_text: searchableText,
          category_id: category?.id || null,
          tags: JSON.stringify(claudeResult.tags),
          extracted_urls: JSON.stringify(claudeResult.extracted_urls),
          status: 'processed',
          processed_date: new Date().toISOString(),
        });

        db.updateQueueStatus(queueItem.id, 'completed');
        logger.info(`Vision processed: "${claudeResult.title}" (Category: ${claudeResult.category})`);

        // Cleanup temp images
        for (const imgPath of fetched.imagePaths) {
          try { fs.unlinkSync(imgPath); } catch {}
        }

        return;
      } catch (err: any) {
        logger.error(`Vision processing failed: ${err.message}. Falling back to pending_description.`);
        // Fall through to pending_description
      }
    }

    // Step 2.6: If still no text and no images (or vision failed), save as pending_description
    if (!fullText || fullText.trim().length < 20) {
      logger.info(`No text content extracted for ${url}. Saving as pending_description.`);
      const category = db.getCategoryBySlug('otro');
      db.insertContent({
        url,
        title: fetched.title || 'Contenido sin texto',
        source_platform: fetched.platform,
        content_type: fetched.contentType,
        raw_content: fullText || '',
        summary: '⏳ Este contenido no tiene texto extraíble. Usa /describir para categorizarlo.',
        key_points: JSON.stringify([]),
        searchable_text: fetched.title || url,
        category_id: category?.id || null,
        tags: JSON.stringify([]),
        extracted_urls: JSON.stringify([]),
        status: 'pending_description' as any,
        processed_date: new Date().toISOString(),
      });
      db.updateQueueStatus(queueItem.id, 'completed');
      logger.info(`Saved as pending_description: ${url}`);
      return;
    }

    // Step 3: Process with Claude (summarize, categorize, extract)
    logger.info(`Step 3: Processing with Claude...`);
    const claudeResult = await processContent(
      fullText,
      url,
      fetched.platform,
      fetched.title
    );

    // Step 4: Resolve category
    let category = db.getCategoryByName(claudeResult.category);
    if (!category) {
      // Try to find a close match or use "Otro"
      category = db.getCategoryBySlug('otro');
    }

    // Step 5: Build searchable text (combines all useful text for FTS)
    const searchableText = [
      claudeResult.title,
      claudeResult.summary,
      claudeResult.key_points.join('. '),
      claudeResult.tags.join(' '),
      fetched.title,
    ].filter(Boolean).join(' | ');

    // Step 6: Store in database
    logger.info(`Step 4: Storing in database...`);
    const contentId = db.insertContent({
      url,
      title: claudeResult.title,
      source_platform: fetched.platform,
      content_type: fetched.contentType,
      raw_content: fullText.substring(0, 50000), // Limit storage
      transcription,
      summary: claudeResult.summary,
      key_points: JSON.stringify(claudeResult.key_points),
      searchable_text: searchableText,
      category_id: category?.id || null,
      tags: JSON.stringify(claudeResult.tags),
      extracted_urls: JSON.stringify(claudeResult.extracted_urls),
      status: 'processed',
      processed_date: new Date().toISOString(),
    });

    // Mark queue item as completed
    db.updateQueueStatus(queueItem.id, 'completed');
    logger.info(`Successfully processed: "${claudeResult.title}" (ID: ${contentId}, Category: ${claudeResult.category})`);

  } catch (err: any) {
    logger.error(`Failed to process queue item #${queueItem.id}: ${err.message}`);

    // Retry logic
    const newRetryCount = (queueItem.retry_count || 0) + 1;
    if (newRetryCount < 3) {
      db.updateQueueStatus(queueItem.id, 'pending', newRetryCount);
      logger.info(`Queue item #${queueItem.id} will be retried (attempt ${newRetryCount}/3)`);
    } else {
      db.updateQueueStatus(queueItem.id, 'failed', newRetryCount);
      logger.error(`Queue item #${queueItem.id} permanently failed after 3 retries`);
    }

    throw err; // Re-throw so the batch processor knows about the failure
  }
}
