/**
 * Standalone script to run batch processing (npm run process)
 * Useful for manual processing or testing outside the cron schedule.
 */
import { runMigrations } from '../database/db';
import { processBatch } from './batch-processor';
import { logger } from '../config/logger';

async function main() {
  logger.info('Manual batch processing started...');
  runMigrations();

  const result = await processBatch();

  logger.info(`Done! Processed: ${result.processed}, Failed: ${result.failed}, Total: ${result.total}`);
  process.exit(0);
}

main().catch(err => {
  logger.error(`Batch processing failed: ${err}`);
  process.exit(1);
});
