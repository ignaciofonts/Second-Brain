import * as db from '../database/db';
import { processQueueItem } from './content.processor';
import { logger } from '../config/logger';
import { CONFIG } from '../config/constants';

/**
 * Process all pending items in the queue (called by cron or on-demand)
 */
export async function processBatch(): Promise<{ processed: number; failed: number; total: number }> {
  const pendingItems = db.getPendingQueueItems(CONFIG.maxItemsPerBatch);

  if (pendingItems.length === 0) {
    logger.info('No pending items in queue');
    return { processed: 0, failed: 0, total: 0 };
  }

  logger.info(`Starting batch processing: ${pendingItems.length} items`);

  let processed = 0;
  let failed = 0;

  for (const item of pendingItems) {
    try {
      await processQueueItem(item);
      processed++;

      // Small delay between items to respect API rate limits
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (err: any) {
      failed++;
      logger.error(`Batch item failed: ${item.url} - ${err.message}`);
    }
  }

  const summary = { processed, failed, total: pendingItems.length };
  logger.info(`Batch complete: ${processed} processed, ${failed} failed out of ${pendingItems.length}`);
  return summary;
}
