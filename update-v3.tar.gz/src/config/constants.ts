import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

export const CONFIG = {
  port: parseInt(process.env.PORT || '3100', 10),
  nodeEnv: process.env.NODE_ENV || 'development',

  // Telegram
  telegramToken: process.env.TELEGRAM_BOT_TOKEN || '',

  // APIs
  openaiKey: process.env.OPENAI_API_KEY || '',
  anthropicKey: process.env.ANTHROPIC_API_KEY || '',

  // Database
  databasePath: process.env.DATABASE_PATH || path.join(__dirname, '../../data/second-brain.sqlite'),

  // Processing
  cronSchedule: process.env.CRON_SCHEDULE || '0 2 * * *',
  maxItemsPerBatch: parseInt(process.env.MAX_ITEMS_PER_BATCH || '10', 10),
  maxRetryCount: parseInt(process.env.MAX_RETRY_COUNT || '3', 10),

  // Web panel
  webPanelEnabled: process.env.WEB_PANEL_ENABLED !== 'false',

  // Temp files
  tempDir: path.join(__dirname, '../../tmp'),
};

// Default categories for the Second Brain
export const DEFAULT_CATEGORIES = [
  { name: 'Tech',                   slug: 'tech',          color: '#3B82F6', icon: '💻', description: 'Tecnología, software, gadgets' },
  { name: 'AI',                     slug: 'ai',            color: '#8B5CF6', icon: '🤖', description: 'Inteligencia artificial, machine learning, LLMs' },
  { name: 'Jardinería',             slug: 'jardineria',    color: '#10B981', icon: '🌿', description: 'Jardinería, plantas, cultivo' },
  { name: 'Semillas',               slug: 'semillas',      color: '#F59E0B', icon: '🌱', description: 'Semillas, variedades, proveedores' },
  { name: 'Maquinaria Agrícola',    slug: 'maquinaria',    color: '#EF4444', icon: '🚜', description: 'Maquinaria agrícola, herramientas de campo' },
  { name: 'Hardware',               slug: 'hardware',      color: '#6366F1', icon: '🔧', description: 'Herramientas, ferretería, bricolaje' },
  { name: 'Pensamiento Filosófico', slug: 'filosofia',     color: '#EC4899', icon: '🏛️', description: 'Filosofía, reflexiones, pensamiento crítico' },
  { name: 'Política',               slug: 'politica',      color: '#F97316', icon: '🏛️', description: 'Política, actualidad, opinión' },
  { name: 'Finanzas',               slug: 'finanzas',      color: '#14B8A6', icon: '💰', description: 'Inversiones, economía, finanzas personales' },
  { name: 'Salud',                  slug: 'salud',         color: '#06B6D4', icon: '❤️', description: 'Salud, bienestar, nutrición' },
  { name: 'Otro',                   slug: 'otro',          color: '#6B7280', icon: '📌', description: 'Contenido sin categoría específica' },
];
