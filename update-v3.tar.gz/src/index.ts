import express from 'express';
import cors from 'cors';
import path from 'path';
import cron from 'node-cron';
import { CONFIG } from './config/constants';
import { logger } from './config/logger';
import { runMigrations } from './database/db';
import { startTelegramBot, getBotInstance } from './services/telegram.service';
import { processBatch } from './processors/batch-processor';
import apiRoutes from './routes/api';
import fs from 'fs';

// ============================================
// Ensure directories exist
// ============================================
const dirs = [
  path.dirname(CONFIG.databasePath),
  CONFIG.tempDir,
  path.join(__dirname, '../logs'),
];
for (const dir of dirs) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// ============================================
// Initialize Database
// ============================================
logger.info('Initializing database...');
runMigrations();

// ============================================
// Start Telegram Bot
// ============================================
if (CONFIG.telegramToken) {
  startTelegramBot();
} else {
  logger.warn('TELEGRAM_BOT_TOKEN not set. Bot is disabled.');
}

// ============================================
// Express Server (API + Web Panel)
// ============================================
const app = express();

app.use(cors());
app.use(express.json());

// API routes
app.use('/api', apiRoutes);

// Web panel (static files)
if (CONFIG.webPanelEnabled) {
  const publicPath = path.join(__dirname, 'web/public');
  app.use(express.static(publicPath));

  // SPA fallback
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(publicPath, 'index.html'));
    }
  });

  logger.info(`Web panel enabled, serving from ${publicPath}`);
}

app.listen(CONFIG.port, () => {
  logger.info(`Second Brain server running on http://localhost:${CONFIG.port}`);
  logger.info(`API: http://localhost:${CONFIG.port}/api`);
  if (CONFIG.webPanelEnabled) {
    logger.info(`Web Panel: http://localhost:${CONFIG.port}`);
  }
});

// ============================================
// Scheduled Processing (Cron)
// ============================================
if (CONFIG.cronSchedule) {
  cron.schedule(CONFIG.cronSchedule, async () => {
    logger.info('Cron job triggered: processing pending queue items...');
    try {
      const result = await processBatch();

      // Notify via Telegram if there were results
      const bot = getBotInstance();
      if (bot && result.total > 0) {
        // We could notify the last chat_id that submitted items
        logger.info(`Cron batch complete: ${result.processed}/${result.total} processed`);
      }
    } catch (err) {
      logger.error(`Cron batch failed: ${err}`);
    }
  }, {
    timezone: process.env.TZ || 'Europe/Madrid',
  });

  logger.info(`Cron job scheduled: ${CONFIG.cronSchedule} (${process.env.TZ || 'Europe/Madrid'})`);
}

// ============================================
// Graceful Shutdown
// ============================================
process.on('SIGINT', () => {
  logger.info('Shutting down gracefully...');
  const bot = getBotInstance();
  if (bot) bot.stopPolling();
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down...');
  const bot = getBotInstance();
  if (bot) bot.stopPolling();
  process.exit(0);
});
