# Second Brain - Guía de Despliegue en VPS (Hostinger)

## Requisitos previos

1. **Node.js 18+** en el VPS
2. **yt-dlp** instalado: `pip install yt-dlp` o `sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp && sudo chmod a+rx /usr/local/bin/yt-dlp`
3. **ffmpeg** instalado: `sudo apt install ffmpeg`
4. **Bot de Telegram** creado vía @BotFather
5. **API keys**: OpenAI (Whisper) y Anthropic (Claude)

## Paso 1: Crear el bot de Telegram

1. Abre Telegram y busca @BotFather
2. Envía `/newbot`
3. Pon un nombre: `Mi Second Brain`
4. Pon un username: `mi_secondbrain_bot` (debe terminar en `_bot`)
5. Guarda el token que te da

## Paso 2: Subir el proyecto al VPS

```bash
# Desde tu máquina local
scp -r second-brain/ user@tu-vps-ip:/home/user/second-brain

# O con git
cd /home/user
git clone <tu-repo> second-brain
```

## Paso 3: Instalar dependencias

```bash
cd /home/user/second-brain
npm install
```

## Paso 4: Configurar variables de entorno

```bash
cp .env.example .env
nano .env
```

Rellena los valores:
```
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
DATABASE_PATH=/home/user/second-brain/data/second-brain.sqlite
PORT=3100
```

## Paso 5: Compilar y ejecutar

```bash
npm run build
npm start
```

## Paso 6: Configurar PM2 (proceso persistente)

```bash
# Instalar PM2 si no lo tienes
npm install -g pm2

# Iniciar la aplicación
pm2 start dist/index.js --name second-brain

# Que se reinicie automáticamente al arrancar el VPS
pm2 startup
pm2 save
```

## Paso 7: Configurar Nginx (opcional, para el panel web)

Si quieres acceder al panel web desde un dominio:

```nginx
server {
    listen 80;
    server_name brain.tudominio.com;

    location / {
        proxy_pass http://localhost:3100;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/second-brain /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Comandos útiles

```bash
# Ver logs en tiempo real
pm2 logs second-brain

# Procesar la cola manualmente
npm run process

# Reiniciar
pm2 restart second-brain

# Ver estado
pm2 status
```

## Estructura de la app

```
second-brain/
├── src/                    # Código fuente TypeScript
├── dist/                   # Código compilado (después de npm run build)
├── data/                   # Base de datos SQLite (creada automáticamente)
├── tmp/                    # Archivos temporales (audio descargado, etc.)
├── logs/                   # Archivos de log
├── .env                    # Configuración (NO subir a git)
└── package.json
```

## Comandos del Bot de Telegram

| Comando | Descripción |
|---------|-------------|
| Enviar URL | Añade a la cola de procesamiento |
| `/ya <url>` | Procesa una URL inmediatamente |
| `/procesar` | Procesa toda la cola ahora |
| `/buscar <texto>` | Busca en tu Second Brain |
| `/ask <pregunta>` | Pregunta con IA (busca local + Claude) |
| `/categorias` | Ver categorías y conteo |
| `/stats` | Estadísticas generales |
| `/recientes` | Últimos 10 items guardados |
| Texto libre | Lo interpreta como pregunta al /ask |

## Costes estimados

- **Whisper API**: ~$0.006/minuto de audio
- **Claude API**: ~$0.003-0.015 por contenido procesado (depende del largo)
- **Procesamiento diario de 5 items**: ~$0.10-0.15/día ≈ $3-5/mes
