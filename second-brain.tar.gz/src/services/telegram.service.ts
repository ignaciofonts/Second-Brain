import TelegramBot from 'node-telegram-bot-api';
import { CONFIG } from '../config/constants';
import { logger } from '../config/logger';
import * as db from '../database/db';
import { searchContent } from '../database/db';
import { augmentedSearch } from './claude.service';
import { processBatch } from '../processors/batch-processor';
import { processQueueItem } from '../processors/content.processor';
import { isValidUrl, cleanUrl } from '../utils/url-detector';

let bot: TelegramBot;

export function startTelegramBot(): TelegramBot {
  bot = new TelegramBot(CONFIG.telegramToken, { polling: true });

  logger.info('Telegram bot starting...');

  // ============================================
  // /start - Welcome message
  // ============================================
  bot.onText(/\/start/, (msg) => {
    const welcome = `🧠 *Second Brain* - Tu memoria digital personal

Puedo guardar y organizar contenido de redes sociales para que lo consultes cuando quieras.

*Cómo usarme:*

📥 *Guardar contenido:* Envíame cualquier enlace (YouTube, Instagram, X, LinkedIn, web...)

🔍 *Buscar:* /buscar semillas de tomate
❓ *Preguntar:* /ask ¿qué herramientas tengo guardadas?
📊 *Categorías:* /categorias
📈 *Estadísticas:* /stats
⚡ *Procesar ahora:* /procesar (procesa la cola inmediatamente)
📋 *Últimos guardados:* /recientes

¡Envíame un enlace para empezar!`;

    bot.sendMessage(msg.chat.id, welcome, { parse_mode: 'Markdown' });
  });

  // ============================================
  // URL Detection - Add to queue
  // ============================================
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;

    const text = msg.text.trim();

    // Check if it's a URL
    if (isValidUrl(text)) {
      await handleUrl(msg.chat.id, text);
      return;
    }

    // Check if message contains a URL among other text
    const urlMatch = text.match(/https?:\/\/[^\s]+/);
    if (urlMatch) {
      await handleUrl(msg.chat.id, urlMatch[0]);
      return;
    }

    // If it's just text (not a command, not a URL), treat it as a question
    await handleQuestion(msg.chat.id, text);
  });

  // ============================================
  // /buscar <query> - Search saved content
  // ============================================
  bot.onText(/\/buscar (.+)/, async (msg, match) => {
    if (!match) return;
    const query = match[1].trim();
    await handleSearch(msg.chat.id, query);
  });

  // ============================================
  // /ask <question> - Augmented search with Claude
  // ============================================
  bot.onText(/\/ask (.+)/, async (msg, match) => {
    if (!match) return;
    const question = match[1].trim();
    await handleQuestion(msg.chat.id, question);
  });

  // ============================================
  // /categorias - List categories with counts
  // ============================================
  bot.onText(/\/categorias/, async (msg) => {
    const stats = db.getStats();
    const catList = (stats.byCategory as any[])
      .filter((c: any) => c.count > 0)
      .map((c: any) => `${c.icon} *${c.name}*: ${c.count} items`)
      .join('\n');

    const message = catList
      ? `📂 *Tus categorías:*\n\n${catList}\n\n_Total: ${stats.total} contenidos guardados_`
      : '📂 Aún no tienes contenido guardado. ¡Envíame un enlace para empezar!';

    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /stats - Dashboard stats
  // ============================================
  bot.onText(/\/stats/, async (msg) => {
    const stats = db.getStats();
    const platformList = (stats.byPlatform as any[])
      .map((p: any) => `  ${platformEmoji(p.source_platform)} ${p.source_platform}: ${p.count}`)
      .join('\n');

    const message = `📈 *Estadísticas de tu Second Brain*

📚 Total guardados: *${stats.total}*
⏳ En cola: *${stats.pending}*

*Por plataforma:*
${platformList || '  Ninguna aún'}

*Últimos guardados:*
${(stats.recent as any[]).map((r: any) => `  ${r.icon || '📌'} ${r.title?.substring(0, 50)}`).join('\n') || '  Ninguno aún'}`;

    bot.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /recientes - Last 10 saved items
  // ============================================
  bot.onText(/\/recientes/, async (msg) => {
    const { items } = db.getContentByCategory(undefined, 1, 10);
    if (items.length === 0) {
      bot.sendMessage(msg.chat.id, '📋 No hay contenido guardado aún.');
      return;
    }

    const list = items.map((item: any, i: number) =>
      `${i + 1}. ${item.category_icon || '📌'} *${escapeMarkdown(item.title || 'Sin título')}*\n   _${item.category_name || 'Sin categoría'}_ | ${formatDate(item.added_date)}\n   ${item.url}`
    ).join('\n\n');

    bot.sendMessage(msg.chat.id, `📋 *Últimos guardados:*\n\n${list}`, { parse_mode: 'Markdown' });
  });

  // ============================================
  // /procesar - Process queue now
  // ============================================
  bot.onText(/\/procesar/, async (msg) => {
    const pending = db.getPendingQueueItems();
    if (pending.length === 0) {
      bot.sendMessage(msg.chat.id, '✅ No hay nada pendiente de procesar.');
      return;
    }

    bot.sendMessage(msg.chat.id, `⚙️ Procesando ${pending.length} items pendientes... Te aviso cuando termine.`);

    try {
      const result = await processBatch();
      bot.sendMessage(
        msg.chat.id,
        `✅ *Procesamiento completado*\n\n` +
        `📥 Procesados: ${result.processed}\n` +
        `❌ Fallidos: ${result.failed}\n` +
        `📊 Total: ${result.total}`,
        { parse_mode: 'Markdown' }
      );
    } catch (err) {
      bot.sendMessage(msg.chat.id, `❌ Error durante el procesamiento. Revisa los logs.`);
    }
  });

  // ============================================
  // /procesar_ya - Process a URL immediately (no queue)
  // ============================================
  bot.onText(/\/ya (.+)/, async (msg, match) => {
    if (!match) return;
    const url = match[1].trim();

    if (!isValidUrl(url)) {
      bot.sendMessage(msg.chat.id, '❌ Eso no parece una URL válida.');
      return;
    }

    bot.sendMessage(msg.chat.id, `⚡ Procesando inmediatamente: ${url}`);

    const queueItem = db.addToQueue(cleanUrl(url), msg.chat.id.toString());
    if (!queueItem) {
      bot.sendMessage(msg.chat.id, '⚠️ Esta URL ya está guardada o en cola.');
      return;
    }

    try {
      await processQueueItem(queueItem);
      bot.sendMessage(msg.chat.id, `✅ ¡Procesado y guardado en tu Second Brain!`);
    } catch (err: any) {
      bot.sendMessage(msg.chat.id, `❌ Error procesando: ${err.message?.substring(0, 100)}`);
    }
  });

  logger.info('Telegram bot started successfully');
  return bot;
}

// ============================================
// Handler functions
// ============================================

async function handleUrl(chatId: number, url: string): Promise<void> {
  const cleanedUrl = cleanUrl(url);
  const queueItem = db.addToQueue(cleanedUrl, chatId.toString());

  if (!queueItem) {
    bot.sendMessage(chatId, '⚠️ Esta URL ya está guardada o en cola de procesamiento.');
    return;
  }

  bot.sendMessage(
    chatId,
    `📥 *URL guardada en cola*\n\n🔗 ${cleanedUrl}\n\n_Se procesará automáticamente. Usa /procesar para procesarla ahora o /ya ${cleanedUrl} para procesamiento inmediato._`,
    { parse_mode: 'Markdown' }
  );
}

async function handleSearch(chatId: number, query: string): Promise<void> {
  const results = searchContent(query, 5);

  if (results.length === 0) {
    bot.sendMessage(chatId, `🔍 No encontré nada para "${query}" en tu Second Brain.`);
    return;
  }

  const list = results.map((r, i) =>
    `${i + 1}. *${escapeMarkdown(r.item.title || 'Sin título')}*\n   📂 ${r.category_name}\n   ${r.snippet}...\n   🔗 ${r.item.url}`
  ).join('\n\n');

  bot.sendMessage(chatId, `🔍 *Resultados para "${escapeMarkdown(query)}":*\n\n${list}`, { parse_mode: 'Markdown' });
}

async function handleQuestion(chatId: number, question: string): Promise<void> {
  bot.sendMessage(chatId, '🤔 Buscando en tu Second Brain...');

  // First, search locally
  const localResults = searchContent(question, 5);

  // Then augment with Claude
  const answer = await augmentedSearch(question, localResults);

  bot.sendMessage(chatId, answer, { parse_mode: 'Markdown' }).catch(() => {
    // If Markdown fails, send as plain text
    bot.sendMessage(chatId, answer);
  });
}

// ============================================
// Utilities
// ============================================

function platformEmoji(platform: string): string {
  const emojis: Record<string, string> = {
    youtube: '🎬',
    twitter: '🐦',
    instagram: '📸',
    linkedin: '💼',
    web: '🌐',
    unknown: '❓',
  };
  return emojis[platform] || '📌';
}

function escapeMarkdown(text: string): string {
  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
}

export function getBotInstance(): TelegramBot | undefined {
  return bot;
}
