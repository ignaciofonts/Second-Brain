// ============================================
// Second Brain - Web Panel Application
// ============================================

const API = '';
let currentCategory = 'all';
let currentPage = 1;
let searchTimeout = null;

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  loadCategories();
  loadContent();
  setupSearchListener();
  setupKeyboardShortcuts();
});

// ============================================
// Data Loading
// ============================================

async function loadStats() {
  try {
    const stats = await fetchJson('/api/stats');
    document.getElementById('totalCount').textContent = `${stats.total} items`;
    document.getElementById('pendingCount').textContent = `${stats.pending} pendientes`;
    document.getElementById('count-all').textContent = stats.total;

    // Platform stats
    const platformEl = document.getElementById('platformStats');
    const platformEmojis = {
      youtube: '🎬', twitter: '🐦', instagram: '📸',
      linkedin: '💼', web: '🌐', unknown: '❓'
    };
    platformEl.innerHTML = stats.byPlatform
      .map(p => `<div class="platform-item">
        <span>${platformEmojis[p.source_platform] || '📌'} ${p.source_platform}</span>
        <span>${p.count}</span>
      </div>`).join('');
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

async function loadCategories() {
  try {
    const stats = await fetchJson('/api/stats');
    const nav = document.getElementById('categoryNav');

    // Keep the "Todos" link
    const allLink = nav.querySelector('[data-slug="all"]');

    // Add category links
    stats.byCategory.forEach(cat => {
      const link = document.createElement('a');
      link.href = '#';
      link.className = 'cat-link';
      link.dataset.slug = cat.slug;
      link.innerHTML = `
        <span class="cat-icon">${cat.icon}</span>
        <span class="cat-name">${cat.name}</span>
        <span class="cat-count">${cat.count}</span>
      `;
      link.addEventListener('click', (e) => {
        e.preventDefault();
        setActiveCategory(cat.slug);
      });
      nav.appendChild(link);
    });

    // Set up "Todos" click
    allLink.addEventListener('click', (e) => {
      e.preventDefault();
      setActiveCategory('all');
    });
  } catch (err) {
    console.error('Failed to load categories:', err);
  }
}

async function loadContent(category, page = 1) {
  const grid = document.getElementById('contentGrid');
  const empty = document.getElementById('emptyState');
  const loading = document.getElementById('loading');

  grid.style.display = 'none';
  empty.style.display = 'none';
  loading.style.display = 'block';

  try {
    const params = new URLSearchParams({ page, limit: 20 });
    if (category && category !== 'all') params.set('category', category);

    const data = await fetchJson(`/api/content?${params}`);

    loading.style.display = 'none';

    if (data.items.length === 0) {
      empty.style.display = 'block';
      document.getElementById('pagination').innerHTML = '';
      return;
    }

    grid.style.display = 'grid';
    grid.innerHTML = data.items.map(item => createCard(item)).join('');
    renderPagination(data.page, data.totalPages);
  } catch (err) {
    loading.style.display = 'none';
    console.error('Failed to load content:', err);
  }
}

async function searchContent(query) {
  const grid = document.getElementById('contentGrid');
  const empty = document.getElementById('emptyState');
  const loading = document.getElementById('loading');

  if (!query || query.length < 2) {
    loadContent(currentCategory, 1);
    return;
  }

  grid.style.display = 'none';
  empty.style.display = 'none';
  loading.style.display = 'block';

  try {
    const data = await fetchJson(`/api/search?q=${encodeURIComponent(query)}`);
    loading.style.display = 'none';

    if (data.results.length === 0) {
      empty.style.display = 'block';
      empty.querySelector('h3').textContent = `No se encontró nada para "${query}"`;
      document.getElementById('pagination').innerHTML = '';
      return;
    }

    grid.style.display = 'grid';
    grid.innerHTML = data.results.map(r => createCard(r.item)).join('');
    document.getElementById('pagination').innerHTML = '';
  } catch (err) {
    loading.style.display = 'none';
    console.error('Search failed:', err);
  }
}

// ============================================
// UI Components
// ============================================

function createCard(item) {
  const platformEmoji = {
    youtube: '🎬', twitter: '🐦', instagram: '📸',
    linkedin: '💼', web: '🌐', unknown: '📌'
  };

  const tags = safeParse(item.tags, []).slice(0, 4);
  const date = formatDate(item.added_date);
  const catColor = item.category_color || '#6B7280';

  return `
    <div class="content-card" onclick="openDetail(${item.id})">
      <div class="card-header">
        <div class="card-platform">${platformEmoji[item.source_platform] || '📌'}</div>
        <div class="card-title">${escapeHtml(item.title || 'Sin título')}</div>
      </div>
      <div class="card-summary">${escapeHtml(item.summary || '')}</div>
      <div class="card-tags">
        ${tags.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join('')}
      </div>
      <div class="card-footer">
        <span class="card-category" style="color:${catColor}; border-color:${catColor}30">
          ${item.category_icon || '📌'} ${escapeHtml(item.category_name || 'Sin categoría')}
        </span>
        <span class="card-date">${date}</span>
      </div>
    </div>
  `;
}

function renderPagination(current, total) {
  const el = document.getElementById('pagination');
  if (total <= 1) { el.innerHTML = ''; return; }

  let html = '';
  html += `<button ${current <= 1 ? 'disabled' : ''} onclick="goToPage(${current - 1})">&larr;</button>`;
  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= current - 2 && i <= current + 2)) {
      html += `<button class="${i === current ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
    } else if (i === current - 3 || i === current + 3) {
      html += `<button disabled>...</button>`;
    }
  }
  html += `<button ${current >= total ? 'disabled' : ''} onclick="goToPage(${current + 1})">&rarr;</button>`;
  el.innerHTML = html;
}

// ============================================
// Detail Modal
// ============================================

async function openDetail(id) {
  try {
    const item = await fetchJson(`/api/content/${id}`);
    const keyPoints = safeParse(item.key_points, []);
    const extractedUrls = safeParse(item.extracted_urls, []);
    const tags = safeParse(item.tags, []);

    const modalBody = document.getElementById('modalBody');
    modalBody.innerHTML = `
      <h2 class="detail-title">${escapeHtml(item.title || 'Sin título')}</h2>
      <div class="detail-meta">
        <span>📅 ${formatDate(item.added_date)}</span>
        <span>📂 ${escapeHtml(item.category_name || 'Sin categoría')}</span>
        <span>🔗 ${item.source_platform}</span>
      </div>

      <div class="detail-section">
        <h3>Resumen</h3>
        <p class="detail-summary">${escapeHtml(item.summary || 'Sin resumen disponible.')}</p>
      </div>

      ${keyPoints.length > 0 ? `
      <div class="detail-section">
        <h3>Puntos clave</h3>
        <ul class="detail-key-points">
          ${keyPoints.map(p => `<li>${escapeHtml(p)}</li>`).join('')}
        </ul>
      </div>
      ` : ''}

      ${tags.length > 0 ? `
      <div class="detail-section">
        <h3>Tags</h3>
        <div class="card-tags">
          ${tags.map(t => `<span class="tag">${escapeHtml(t)}</span>`).join('')}
        </div>
      </div>
      ` : ''}

      ${extractedUrls.length > 0 ? `
      <div class="detail-section">
        <h3>Enlaces mencionados</h3>
        <div class="detail-urls">
          ${extractedUrls.map(u => `<a href="${escapeHtml(u.url)}" target="_blank" rel="noopener">${escapeHtml(u.context || u.url)}</a>`).join('')}
        </div>
      </div>
      ` : ''}

      <a href="${escapeHtml(item.url)}" target="_blank" rel="noopener" class="detail-link">Ver contenido original →</a>
    `;

    document.getElementById('detailModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
  } catch (err) {
    console.error('Failed to load detail:', err);
  }
}

function closeModal() {
  document.getElementById('detailModal').style.display = 'none';
  document.body.style.overflow = '';
}

// ============================================
// Event Handlers
// ============================================

function setActiveCategory(slug) {
  currentCategory = slug;
  currentPage = 1;

  document.querySelectorAll('.cat-link').forEach(el => {
    el.classList.toggle('active', el.dataset.slug === slug);
  });

  document.getElementById('searchInput').value = '';
  loadContent(slug, 1);
}

function goToPage(page) {
  currentPage = page;
  loadContent(currentCategory, page);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setupSearchListener() {
  const input = document.getElementById('searchInput');
  input.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      searchContent(e.target.value.trim());
    }, 400);
  });
}

function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Cmd/Ctrl + K -> Focus search
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      document.getElementById('searchInput').focus();
    }
    // Escape -> Close modal
    if (e.key === 'Escape') {
      closeModal();
    }
  });
}

// ============================================
// Utilities
// ============================================

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function safeParse(json, fallback) {
  if (!json) return fallback;
  if (Array.isArray(json)) return json;
  try { return JSON.parse(json); } catch { return fallback; }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    return new Date(dateStr).toLocaleDateString('es-ES', {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  } catch { return dateStr; }
}
